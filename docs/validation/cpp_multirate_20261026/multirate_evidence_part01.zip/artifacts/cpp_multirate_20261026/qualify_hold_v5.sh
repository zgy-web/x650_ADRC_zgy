set -e
source /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_multirate_20261026/environment.sh
M=/root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_multirate_20261026
S=$M/source
CFLAGS="-std=c++17 -O2 -I$S/control_packages/x650_wholebody_v1/native -I$S/control_packages/x650_wholebody_v1/benchmark/include -I/usr/include/jsoncpp -I$S/ros2_ws/src/flyarm_mpc_cpp/include -I$S/ros2_ws/src/flyarm_control_gateway/include -I/root/autodl-tmp/flyarm_state_cpp_20261024/install/flyarm_state_cpp/include"
STATE=$(ros2 pkg prefix flyarm_state_cpp)
c++ $CFLAGS -I"$STATE/include" "$S/scripts/x650_cpp_multirate_sequence.cpp" -L"$M/build" -Wl,-rpath,"$M/build" -lx650_mpc_core -ljsoncpp -lcrypto -ldl -o "$M/x650_cpp_multirate_sequence"
c++ $CFLAGS "$S/scripts/x650_cpp_recovery_replay.cpp" -L"$M/build" -Wl,-rpath,"$M/build" -lx650_mpc_core -ljsoncpp -lcrypto -ldl -o "$M/legacy_replay"
echo BUILD_COMPLETE

/usr/bin/python3 scripts/qualify_x650_multirate.py --stage "$M" --case tip_hold --input-name inputs_v5
