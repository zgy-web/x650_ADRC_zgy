set -e
source /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_multirate_20261026/environment.sh
/usr/bin/python3 scripts/audit_x650_cpp_multirate.py --launch-dir /root/autodl-tmp/safe-aerial-manipulator-testbed/runs/x650_cpp_multirate_launch_20261026_220335_24241 --run-dir /root/autodl-tmp/safe-aerial-manipulator-testbed/runs/x650_cpp_multirate_wrench_v1_20261026_220417_24257 --output /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_multirate_20261026/wrench_audit_v1
