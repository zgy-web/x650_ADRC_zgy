cd /root/autodl-tmp/safe-aerial-manipulator-testbed
source artifacts/cpp_fast_20261024/fast_environment_v1.sh
source artifacts/cpp_interval_hard_20261026/ros_v3/install/local_setup.bash
source artifacts/cpp_multirate_20261026/ros/install/local_setup.bash
export LD_LIBRARY_PATH="$PWD/artifacts/cpp_multirate_20261026/build:$LD_LIBRARY_PATH"
export PYTHONPATH="$PWD:$PWD/src:$PWD/scripts:$PWD/control_packages/x650_wholebody_v1:$PYTHONPATH"
