#!/bin/bash
set -e
source /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_multirate_20261026/environment.sh
M=$PWD/artifacts/cpp_multirate_20261026
/usr/bin/python3 scripts/check_x650_multirate_legacy.py --stage "$M" --regression artifacts/cpp_interval_hard_20261026/regression_v3/report.json
/usr/bin/python3 scripts/qualify_x650_multirate.py --stage "$M" --case tip_hold
