set -e
source /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_multirate_20261026/environment.sh
M=/root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_multirate_20261026
/usr/bin/python3 scripts/qualify_x650_multirate.py --stage "$M" --case tip_hold --input-name inputs_v3
