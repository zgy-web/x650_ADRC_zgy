#!/bin/bash
set -e
cd /root/autodl-tmp/safe-aerial-manipulator-testbed
source artifacts/cpp_fast_20261024/fast_environment_v1.sh
source artifacts/cpp_interval_hard_20261026/ros_v3/install/local_setup.bash
M=$PWD/artifacts/cpp_multirate_20261026
colcon --log-base "$M/ros/log_gateway" build --base-paths "$M/source/ros2_ws/src/flyarm_control_gateway" --build-base "$M/ros/build" --install-base "$M/ros/install" --cmake-args -DCMAKE_BUILD_TYPE=Release
ctest --test-dir "$M/ros/build/flyarm_control_gateway" --output-on-failure
