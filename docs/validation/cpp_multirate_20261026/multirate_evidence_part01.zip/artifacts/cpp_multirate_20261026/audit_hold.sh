set -e
source /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_multirate_20261026/environment.sh
/usr/bin/python3 scripts/audit_x650_cpp_multirate.py --launch-dir /root/autodl-tmp/safe-aerial-manipulator-testbed/runs/x650_cpp_multirate_launch_20261026_213744_21741 --run-dir /root/autodl-tmp/safe-aerial-manipulator-testbed/runs/x650_cpp_multirate_hold_v1_20261026_213827_21743 --output /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_multirate_20261026/hold_audit_v1
