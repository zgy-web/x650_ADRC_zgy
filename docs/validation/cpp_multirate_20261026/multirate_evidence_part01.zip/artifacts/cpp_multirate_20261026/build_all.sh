#!/bin/bash
set -e
cd /root/autodl-tmp/safe-aerial-manipulator-testbed
source artifacts/cpp_fast_20261024/fast_environment_v1.sh
source artifacts/cpp_interval_hard_20261026/ros_v3/install/local_setup.bash
M=$PWD/artifacts/cpp_multirate_20261026
S=$M/source
cmake -S "$S/control_packages/x650_wholebody_v1/native" -B "$M/build" -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=ON
cmake --build "$M/build" -j4
ctest --test-dir "$M/build" --output-on-failure
colcon --log-base "$M/ros/log_all" build --base-paths "$S/ros2_ws/src/flyarm_control_gateway" "$S/ros2_ws/src/flyarm_mpc_cpp" --build-base "$M/ros/build" --install-base "$M/ros/install" --allow-overriding flyarm_control_gateway flyarm_mpc_cpp --cmake-args -DMAVLINK_INCLUDE_DIR="/root/autodl-tmp/PX4-Autopilot/build/px4_sitl_default/mavlink" -DCMAKE_BUILD_TYPE=Release -DX650_NATIVE_SOURCE_DIR="$S/control_packages/x650_wholebody_v1/native" -DX650_MPC_CORE_LIBRARY="$M/build/libx650_mpc_core.so"
ctest --test-dir "$M/ros/build/flyarm_control_gateway" --output-on-failure
ctest --test-dir "$M/ros/build/flyarm_mpc_cpp" --output-on-failure
source "$M/ros/install/local_setup.bash"
CFLAGS="-std=c++17 -O2 -I$S/control_packages/x650_wholebody_v1/native -I$S/control_packages/x650_wholebody_v1/benchmark/include -I/usr/include/jsoncpp -I$S/ros2_ws/src/flyarm_mpc_cpp/include -I$S/ros2_ws/src/flyarm_control_gateway/include -I/root/autodl-tmp/flyarm_state_cpp_20261024/install/flyarm_state_cpp/include"
STATE=$(ros2 pkg prefix flyarm_state_cpp)
c++ $CFLAGS -I"$STATE/include" "$S/scripts/x650_cpp_multirate_sequence.cpp" -L"$M/build" -Wl,-rpath,"$M/build" -lx650_mpc_core -ljsoncpp -lcrypto -ldl -o "$M/x650_cpp_multirate_sequence"
c++ $CFLAGS "$S/scripts/x650_cpp_recovery_replay.cpp" -L"$M/build" -Wl,-rpath,"$M/build" -lx650_mpc_core -ljsoncpp -lcrypto -ldl -o "$M/legacy_replay"
echo BUILD_COMPLETE
