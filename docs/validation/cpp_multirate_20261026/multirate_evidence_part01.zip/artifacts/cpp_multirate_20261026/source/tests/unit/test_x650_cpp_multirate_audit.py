"""Counterexamples for the new timing checks; original evidence is never retimed."""
from copy import deepcopy
from pathlib import Path
import sys
from types import SimpleNamespace
import unittest

import numpy as np

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'scripts'))
import audit_x650_cpp_multirate as a


def held_fixture():
    c=dict(nodes=15,node_dt=.04,max_dt=.1,command_hold_s=.16,feasibility_tolerance=2e-7,
        bus_period=.005,integration_step=.001,motion=[.01,.02,.01,0.,.012,.02,.001,.1],
        kp=[6.,6.],kd=[.25,.25],velocity_limit=[.3,.3,.2,.45,.35],
        q_lower=[-.75,-.35],q_upper=[.45,.85])
    s=SimpleNamespace(task_time_s=1.,dt_s=.044,control_time_s=11.,joint_time_s=10.998,
        q=[0.,0.],dq=[0.,0.],reference_time_s=.95,reference_r=[0.,0.],
        command_count=1,command_time_s=[.9],command_velocity=[0.,0.],bus_origin_s=0.,
        packet_count=1,packet_send_time_s=[.995],packet_q_ref=[0.,0.],packet_dq_ref=[0.,0.],
        packet_tau_ff=[0.,0.],packet_kp=[6.,6.],packet_kd=[.25,.25])
    fixture=a.interval_fixture(s,c,[0.]*5);plan=np.zeros((15,5))
    pp=a.interval.centre_packets(fixture,plan);end=s.task_time_s+.16
    packets=[p for i,p in enumerate(pp) if i<s.packet_count or p['send_time']+c['motion'][4]<=end]
    offsets=np.cumsum([s.dt_s]+[c['node_dt']]*14)
    queries=sorted(set([s.task_time_s,end,*[s.task_time_s+v for v in offsets if v<.16],
        *[p['send_time']+c['motion'][4] for p in pp if s.task_time_s<=p['send_time']+c['motion'][4]<=end]]))
    begin=s.task_time_s-(s.control_time_s-s.joint_time_s)
    boundaries=sorted(set([begin,*queries,*[p['send_time']+c['motion'][4] for p in pp
        if begin<p['send_time']+c['motion'][4]<=end]]))
    count=sum(max(1,int(np.ceil(dt/c['integration_step']-1e-12))) for dt in np.diff(boundaries) if dt>0)
    wire=[dict(send_time_s=p['send_time'],**{k:v for k,v in p.items() if k!='send_time'}) for p in packets]
    g=dict(required=True,checked=True,passed=True,start_task_s=1.,end_task_s=end,duration_s=.16,
        source_control_time_s=s.control_time_s,source_joint_time_s=s.joint_time_s,
        command=[0.,0.],reference_initial=[0.,0.],reference_final=[0.,0.],envelope=[0.]*8,
        actual_history_packet_count=1,substeps=count,packets=wire,query_times=queries,
        boundary_times=boundaries,boundary_states=[0.]*(4*len(boundaries)))
    return s,c,dict(plan=plan.ravel().tolist(),hold_guard=g)


def tick_fixture():
    issue=1_000_000_000;source=SimpleNamespace(sequence=1,issued_monotonic_ns=issue,control_time_s=10.)
    proposal={'owning_candidate':'original bytes'};ticks=[];sends=[]
    for i,age in enumerate((50_000_000,70_000_000),1):
        at=issue+age
        ticks.append(dict(sequence=i,session_id=4,epoch=1,status=1,output_valid=True,
            command_sequence=1,command_issued_monotonic_ns=issue,command_age_ns=age,
            actual_monotonic_ns=at,scheduled_monotonic_ns=at,source_received_monotonic_ns=at-1_000_000,
            source_sequence=i,repeated=i>1,command=proposal.copy()))
        sends.append(dict(stop_zero=False,dispatch_sequence=i,command_sequence=1,
            sent_monotonic_ns=at+1000,repeated=i>1,sim_s=10.+age/1e9))
    return ticks,sends,[(source,proposal,{})],dict(session_id=4,epoch=1)


class HoldGuardTests(unittest.TestCase):
    def test_nonbus_aligned_prediction_nodes_remain_in_native_grid(self):
        s,c,d=held_fixture();result=a.check_hold_guard(s,c,d)
        self.assertTrue(result['verified'])
        self.assertIn(1.044,d['hold_guard']['query_times'])
        self.assertNotIn(1.044,[p['send_time_s']+c['motion'][4] for p in d['hold_guard']['packets']])

    def test_shortened_guard_fabricated_history_encoding_and_wrong_grid_reject(self):
        for case in ('duration','history','encoding','node','envelope','reference','source_time'):
            s,c,d=held_fixture();g=d['hold_guard']
            if case=='duration':g['duration_s']=.05
            elif case=='history':g['actual_history_packet_count']=0
            elif case=='encoding':g['packets'][-1]['dq_ref'][0]=.001
            elif case=='node':g['query_times'].remove(1.044)
            elif case=='envelope':g['envelope'][6]=.421
            elif case=='reference':g['reference_initial'][0]=.001
            else:g['source_control_time_s']+=.001
            with self.subTest(case=case),self.assertRaises(ValueError):a.check_hold_guard(s,c,d)


class MultiRateTickTests(unittest.TestCase):
    def test_repetition_retains_original_issue_under_explicit_new_lease(self):
        t,s,c,start=tick_fixture()
        result=a.check_ticks(t,s,c,start,convert=lambda x:x)
        self.assertEqual(result['command_age_ms']['maximum'],70.)
        self.assertEqual(result['original_absolute_period_ns'],20_000_000)

    def test_wall_or_physical_expiration_renewed_issue_and_stale_source_reject(self):
        for case in ('wall','physical','renewal','source','slot'):
            t,s,c,start=tick_fixture()
            if case=='wall':
                t[1]['actual_monotonic_ns']=c[0][0].issued_monotonic_ns+161_000_000
                t[1]['command_age_ns']=161_000_000
            elif case=='physical':s[1]['sim_s']=10.160001
            elif case=='renewal':t[1]['command_issued_monotonic_ns']+=20_000_000
            elif case=='source':t[1]['source_received_monotonic_ns']-=25_000_001
            else:t[1]['scheduled_monotonic_ns']+=20_000_000
            with self.subTest(case=case),self.assertRaises(ValueError):a.check_ticks(t,s,c,start,convert=lambda x:x)


if __name__=='__main__':unittest.main()
