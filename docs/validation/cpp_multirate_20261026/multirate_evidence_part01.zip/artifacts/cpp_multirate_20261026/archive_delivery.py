from pathlib import Path
import argparse,json,sys
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'scripts'))
from archive_x650_robustness_raw import files_below,build_archives,identity,read
p=argparse.ArgumentParser();p.add_argument('--hold-audit',type=Path,required=True);p.add_argument('--wrench-audit',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
stage=Path(__file__).resolve().parent;out=a.output.resolve();out.mkdir()
paths=[];context={'scope':'Exact closed multi-rate simulation and software evidence; failed preparations and audits retained; no hardware qualification','audits':[]}
for ap in [a.hold_audit,a.wrench_audit]:
 r=read(ap);context['audits'].append(identity(ap));paths.extend(files_below(ap.parent))
 for key in ['launch_directory','run_directory']:
  d=Path(r[key]);paths.extend(files_below(d))
 launch=read(Path(r['launch_directory'])/'launch.json')
 if not launch.get('runtime_closed'):raise RuntimeError('Cannot archive open runtime')
for x in stage.iterdir():
 if x.is_file():paths.append(x)
 elif x.name.startswith(('tip_hold_inputs_','wrench_fast_inputs_','hold_audit_','wrench_audit_','legacy_cross_version','plots','auditor_','plot_support_')) or x.name=='source':paths.extend(files_below(x))
for rel in ['build/libx650_mpc_core.so','build/libx650_optimization.so','build/test_multirate_core','ros/build/flyarm_control_gateway/test_timing_profile']:
 paths.append(stage/rel)
paths.extend([ROOT/'scripts/archive_x650_robustness_raw.py',ROOT/'scripts/plot_x650_recovery_disturbance.py'])
paths.extend(ROOT.glob('scripts/*multirate*.py'));paths.extend(ROOT.glob('tests/unit/*multirate*.py'))
for ap in [a.hold_audit,a.wrench_audit]:
 cfg=read(Path(read(ap)['launch_directory'])/'task.json');d=ROOT/'generated/imported_models'/cfg['model']
 paths.extend(x for x in files_below(d) if x.suffix.lower() in {'.sdf','.config','.urdf','.json','.yaml','.xml','.txt'})
receipt=build_archives(paths,root=ROOT,output_directory=out,prefix='multirate_evidence',context=context,max_bytes=48*1024*1024)
print(json.dumps({'complete':receipt['complete'],'files':receipt['verified_member_count'],'archives':receipt['archives']},indent=2))
