source /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_fast_20261024/fast_environment_v1.sh
taskset -c 0 nice -n 10 /usr/bin/python3 /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_robustness_20261024/plot_batch_v1.py
