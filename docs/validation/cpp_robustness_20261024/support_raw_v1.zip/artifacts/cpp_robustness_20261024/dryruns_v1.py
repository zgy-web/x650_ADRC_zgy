from pathlib import Path
import sys,json,subprocess
r=Path('/root/autodl-tmp/safe-aerial-manipulator-testbed');sys.path.insert(0,str(r));b=r/'artifacts/cpp_robustness_20261024'
cases=json.loads((b/'case_manifest_v1.json').read_text())['cases']
results=[]
for item in cases:
 d=Path(item['directory']);cmd=['/usr/bin/python3','simulations/x650_cpp_robustness_v1/launch.py','--task',str(d/'task.json'),'--startup-manifest',str(d/'startup_manifest.json'),'--startup-sha256',item['startup_sha256'],'--qualification-manifest',str(d/'qualification_manifest.json'),'--protocol',str(d/'protocol.json'),'--dry-run']
 with (d/'dryrun_v1.log').open('x') as stream:code=subprocess.run(cmd,cwd=r,stdout=stream,stderr=subprocess.STDOUT).returncode
 (d/'dryrun_v1.exit').write_text(str(code)+'\n');results.append(dict(case_id=item['case_id'],exit_code=code))
 if code:break
(b/'dryruns_v1_result.json').write_text(json.dumps(results,indent=2));raise SystemExit(0 if len(results)==3 and all(x['exit_code']==0 for x in results) else 1)
