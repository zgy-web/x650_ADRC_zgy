from pathlib import Path
import json,subprocess,time
r=Path('/root/autodl-tmp/safe-aerial-manipulator-testbed');b=r/'artifacts/cpp_robustness_20261024'
assert not (r/'.amsim/runtime.json').exists()
cases=json.loads((b/'case_manifest_v1.json').read_text())['cases'];results=[]
for item in cases:
 d=Path(item['directory']);assert (d/'dryrun_v1.exit').read_text().strip()=='0'
 before=set((r/'runs').glob('x650_cpp_robust_launch_*'))
 cmd=['/usr/bin/python3','simulations/x650_cpp_robustness_v1/launch.py','--task',str(d/'task.json'),'--startup-manifest',str(d/'startup_manifest.json'),'--startup-sha256',item['startup_sha256'],'--qualification-manifest',str(d/'qualification_manifest.json'),'--protocol',str(d/'protocol.json')]
 with (d/'physical_run_v1.log').open('x') as stream:code=subprocess.run(cmd,cwd=r,stdout=stream,stderr=subprocess.STDOUT).returncode
 (d/'physical_run_v1.exit').write_text(str(code)+'\n');entry=dict(case_id=item['case_id'],run_exit=code,command=cmd)
 launches=set((r/'runs').glob('x650_cpp_robust_launch_*'))-before
 if len(launches)==1:
  launch=next(iter(launches));entry['launch']=str(launch);record=json.loads((launch/'launch.json').read_text());entry['runs']=record.get('run_directories',[])
  if code==0 and len(entry['runs'])==1:
   audit=['taskset','-c','0','nice','-n','10','/usr/bin/python3','scripts/audit_x650_cpp_robustness.py','--launch-dir',str(launch),'--run-dir',entry['runs'][0],'--output',str(d/'audit_v1')]
   with (d/'audit_v1.log').open('x') as stream:acode=subprocess.run(audit,cwd=r,stdout=stream,stderr=subprocess.STDOUT).returncode
   (d/'audit_v1.exit').write_text(str(acode)+'\n');entry['audit_exit']=acode;entry['audit_command']=audit
   if (d/'audit_v1/report.json').exists():
    cert=json.loads((d/'audit_v1/report.json').read_text());entry.update(passed=cert['passed'],error=cert.get('error'),endpoint=cert.get('endpoint'),robustness_performance=cert.get('robustness_performance'))
 results.append(entry);(b/'batch_result_v1.json').write_text(json.dumps(results,indent=2,allow_nan=False)+'\n');print(json.dumps(entry),flush=True)
 if (r/'.amsim/runtime.json').exists():raise RuntimeError('Runtime remained active; next test not started')
(b/'batch_complete_v1.json').write_text(json.dumps(dict(complete=len(results)==3,results=results,delay_tests_enabled=False),indent=2,allow_nan=False)+'\n')
