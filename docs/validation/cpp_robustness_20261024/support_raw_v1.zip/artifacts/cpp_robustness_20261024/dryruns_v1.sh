source /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_fast_20261024/fast_environment_v1.sh
/usr/bin/python3 /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_robustness_20261024/dryruns_v1.py > /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_robustness_20261024/dryruns_v1.log 2>&1
code=$?
printf '%s\n' "$code" > /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_robustness_20261024/dryruns_v1.exit
exit "$code"
