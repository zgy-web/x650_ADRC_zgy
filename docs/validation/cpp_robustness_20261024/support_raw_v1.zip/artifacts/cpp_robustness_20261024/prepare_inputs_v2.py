from pathlib import Path
import json,hashlib
from copy import deepcopy
import sys
sys.path[:0]=['/root/autodl-tmp/safe-aerial-manipulator-testbed','/root/autodl-tmp/safe-aerial-manipulator-testbed/scripts']
from simulations.x650_cpp_robustness_v1 import task,qualification as q
from simulations.x650_cpp_robustness_v1.disturbance import runtime_binding
r=Path('/root/autodl-tmp/safe-aerial-manipulator-testbed');b=r/'artifacts/cpp_robustness_20261024';f=r/'artifacts/cpp_fast_20261024/fast_inputs_v1'
def bound(p):return dict(path=str(p),sha256=q.sha(p))
def write(p,v):p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
original=q.read(f/'task.json');certificate=bound(r/'artifacts/cpp_fast_20261024/fast_audit_v1/report.json');cases=[]
for case_id in task.CASES:
 d=b/case_id;d.mkdir(exist_ok=False)
 phys=pid=None;runtime=None
 if case_id=='wrench_fast':runtime=runtime_binding()
 else:
  suffix='085' if case_id=='mass085_fast' else '115'
  phys=bound(r/('generated/imported_models/amsim_urdf_x650_robust_mass'+suffix+'_v1_flight/robustness_manifest.json'))
  document=q.read(original['pid_profile']);document['model_sha256']=q.read(phys['path'])['model_sha256'];write(d/'pid_profile_rebound.json',document);pid=bound(d/'pid_profile_rebound.json')
 cfg=task.build_task_config(case_id,bound(f/'task.json'),certificate,physical_binding=phys,pid_binding=pid,disturbance_binding=runtime)
 write(d/'task.json',cfg);write(d/'protocol.json',task.protocol(cfg))
 startup=q.read(f/'startup_manifest.json');startup['task_config']=q.identity(d/'task.json');write(d/'startup_manifest.json',startup)
 manifest=dict(kind='x650_cpp_robustness_qualification_v1',simulation_only=True,task_config=q.identity(d/'task.json'),startup_manifest=q.identity(d/'startup_manifest.json'),protocol=q.identity(d/'protocol.json'),nominal_qualification=q.identity(f/'qualification_manifest.json'));write(d/'qualification_manifest.json',manifest)
 cases.append(dict(case_id=case_id,scenario=cfg['scenario'],directory=str(d),startup_sha256=q.sha(d/'startup_manifest.json')))
write(b/'case_manifest_v1.json',dict(cases=cases,delay_tests_enabled=False));print(json.dumps(cases))
