cd /root/autodl-tmp/safe-aerial-manipulator-testbed
export MUJOCO_GL=egl OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
set +e
taskset -c 0 nice -n 10 /root/autodl-tmp/amsim-venv/bin/python scripts/render_x650_cpp_normal.py --report artifacts/cpp_normal_20261024/normal_audit_v1/report.json --output artifacts/cpp_normal_20261024/plots_v1 --plots-only > artifacts/cpp_normal_20261024/plots_v1.log 2>&1
code=$?
printf '%s\n' "$code" > artifacts/cpp_normal_20261024/plots_v1.exit
if [ "$code" != 0 ]; then exit "$code"; fi
taskset -c 0 nice -n 10 /root/autodl-tmp/amsim-venv/bin/python scripts/render_x650_cpp_normal.py --report artifacts/cpp_normal_20261024/normal_audit_v1/report.json --output artifacts/cpp_normal_20261024/preview_v1 --preview-only --preview-time 10 > artifacts/cpp_normal_20261024/preview_v1.log 2>&1
code=$?
printf '%s\n' "$code" > artifacts/cpp_normal_20261024/preview_v1.exit
exit "$code"
