source /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_normal_20261024/normal_environment_v1.sh
set +e
/usr/bin/python3 simulations/x650_cpp_normal_v1/launch.py --task /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_normal_20261024/normal_inputs_v1/task.json --startup-manifest /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_normal_20261024/normal_inputs_v1/startup_manifest.json --startup-sha256 13c6f59179b70402b2539d7025105950d74d8f68c80c73f458c719c0fc70fb40 --qualification-manifest /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_normal_20261024/normal_inputs_v1/qualification_manifest.json --dry-run > /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_normal_20261024/dryrun_v1.log 2>&1
code=$?
printf '%s\n' "$code" > /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_normal_20261024/dryrun_v1.exit
exit "$code"
