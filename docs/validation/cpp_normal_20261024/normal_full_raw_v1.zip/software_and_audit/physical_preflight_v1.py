from pathlib import Path
import json
from simulations.x650_cpp_normal_v1 import task
from simulations.x650_cpp_live_v1 import qualification as q
b=Path('/root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_normal_20261024')
cfg=task.validate_task_config(q.read(b/'normal_inputs_v1/task.json'))
model,provenance=task.preflight(cfg)
r=dict(passed=True,stage=cfg['stage'],duration_s=cfg['duration_s'],model_sha256=model.sha256,provenance=provenance)
(b/'physical_preflight_v1.json').write_text(json.dumps(r,indent=2,allow_nan=False))
print(json.dumps({k:v for k,v in r.items() if k!='provenance'}))
