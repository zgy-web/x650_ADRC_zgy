source /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_pipeline_20261024/stream_environment_v2.sh
set +e
taskset -c 0 nice -n 10 /usr/bin/python3 scripts/export_x650_cpp_normal_inputs.py --accepted-startup artifacts/cpp_pipeline_20261024/hold_inputs_stream_v1/startup_manifest.json --output artifacts/cpp_normal_20261024/dynamic_raw_v1 > artifacts/cpp_normal_20261024/dynamic_export_v1.log 2>&1
code=$?
printf '%s\n' "$code" > artifacts/cpp_normal_20261024/dynamic_export_v1.exit
exit "$code"
