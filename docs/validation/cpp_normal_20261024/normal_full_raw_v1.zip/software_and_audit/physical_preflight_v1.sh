source /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_pipeline_20261024/stream_environment_v2.sh
source /root/autodl-tmp/flyarm_cpp_normal_20261024/install/local_setup.bash
set +e
PYTHONPATH=.:$PYTHONPATH /usr/bin/python3 /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_normal_20261024/physical_preflight_v1.py > /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_normal_20261024/physical_preflight_v1.log 2>&1
code=$?
printf '%s\n' "$code" > /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_normal_20261024/physical_preflight_v1.exit
exit "$code"
