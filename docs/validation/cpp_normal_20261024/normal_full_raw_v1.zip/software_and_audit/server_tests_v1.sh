source /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_pipeline_20261024/stream_environment_v2.sh
source /root/autodl-tmp/flyarm_cpp_normal_20261024/install/local_setup.bash
set +e
/usr/bin/python3 -m unittest tests.unit.test_x650_cpp_normal_qualification tests.unit.test_x650_cpp_normal_audit tests.unit.test_x650_cpp_normal_adapter tests.unit.test_x650_cpp_normal_proofs > artifacts/cpp_normal_20261024/server_tests_v1.log 2>&1
code=$?
printf '%s\n' "$code" > artifacts/cpp_normal_20261024/server_tests_v1.exit
exit "$code"
