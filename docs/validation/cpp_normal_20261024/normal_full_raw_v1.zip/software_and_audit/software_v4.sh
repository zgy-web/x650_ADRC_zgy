source /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_pipeline_20261024/stream_environment_v2.sh
source /root/autodl-tmp/flyarm_cpp_normal_20261024/install/local_setup.bash
set +e
/usr/bin/python3 scripts/probe_x650_cpp_normal_worker.py --sequence /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_normal_20261024/sequence_v3/manifest.json --startup /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_normal_20261024/normal_inputs_v1/startup_manifest.json --worker /root/autodl-tmp/flyarm_cpp_normal_20261024/install/flyarm_mpc_cpp/lib/flyarm_mpc_cpp/isolated_worker --output /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_normal_20261024/worker_ros_v4 > /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_normal_20261024/worker_ros_v4.log 2>&1
code=$?
printf '%s\n' "$code" > /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_normal_20261024/worker_ros_v4.exit
exit "$code"
