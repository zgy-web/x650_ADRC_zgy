source /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_pipeline_20261024/stream_environment_v2.sh
source /root/autodl-tmp/flyarm_cpp_normal_20261024/install/local_setup.bash
set +e
taskset -c 87 /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_normal_20261024/normal_sequence /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_normal_20261024/normal_inputs_v1/startup_manifest.json 13c6f59179b70402b2539d7025105950d74d8f68c80c73f458c719c0fc70fb40 /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_normal_20261024/dynamic_raw_v1/case_000.json /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_normal_20261024/sequence_v2 > /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_normal_20261024/sequence_v2.log 2>&1
code=$?
printf '%s\n' "$code" > /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_normal_20261024/sequence_v2.exit
if [ "$code" != 0 ]; then exit "$code"; fi
/usr/bin/python3 scripts/probe_x650_cpp_normal_worker.py --sequence /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_normal_20261024/sequence_v2/manifest.json --startup /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_normal_20261024/normal_inputs_v1/startup_manifest.json --worker /root/autodl-tmp/flyarm_cpp_normal_20261024/install/flyarm_mpc_cpp/lib/flyarm_mpc_cpp/isolated_worker --output /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_normal_20261024/worker_ros_v2 > /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_normal_20261024/worker_ros_v2.log 2>&1
code=$?
printf '%s\n' "$code" > /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_normal_20261024/worker_ros_v2.exit
exit "$code"
