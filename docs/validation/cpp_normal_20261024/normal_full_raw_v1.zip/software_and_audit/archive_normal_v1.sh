taskset -c 2 nice -n 10 /usr/bin/python3 /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_normal_20261024/archive_normal_v1.py > /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_normal_20261024/archive_normal_v1.log 2>&1
code=$?
printf '%s\n' "$code" > /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_normal_20261024/archive_normal_v1.exit
exit "$code"
