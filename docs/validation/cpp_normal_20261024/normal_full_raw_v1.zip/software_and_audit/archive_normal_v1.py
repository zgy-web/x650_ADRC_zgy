from pathlib import Path
import zipfile,json,hashlib
r=Path('/root/autodl-tmp/safe-aerial-manipulator-testbed');b=r/'artifacts/cpp_normal_20261024'
assert not (r/'.amsim/runtime.json').exists()
assert json.loads((b/'normal_audit_v1/report.json').read_text())['passed'] is True
folders={'accepted/launch':r/'runs/x650_cpp_normal_launch_20261024_172532_46633','accepted/run':r/'runs/x650_cpp_normal_v1_20261024_172622_46636','worker_build_sources':Path('/root/autodl-tmp/flyarm_cpp_normal_20261024/src/flyarm_mpc_cpp')}
files={prefix+'/'+p.relative_to(folder).as_posix():p for prefix,folder in folders.items() for p in folder.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
exclude_dirs={'video_v1','preview_v1','plots_v1'}
exclude_files={'video_v1.log','video_v1.exit','normal_full_raw_v1.zip','normal_full_raw_v1_manifest.json','normal_full_raw_v1_receipt.json','archive_normal_v1.log','archive_normal_v1.exit'}
for p in b.rglob('*'):
 rel=p.relative_to(b)
 if p.is_file() and not set(rel.parts)&exclude_dirs and p.name not in exclude_files and '__pycache__' not in p.parts:
  files['software_and_audit/'+rel.as_posix()]=p
for rel in ['scripts/audit_x650_cpp_normal.py','scripts/audit_x650_cpp_normal_source.py','scripts/audit_x650_cpp_hold.py','scripts/audit_x650_cpp_source.py','scripts/audit_x650_streaming_consumption.py','scripts/export_x650_cpp_normal_inputs.py','scripts/validate_x650_cpp_normal_reference.py','scripts/validate_x650_cpp_pipeline.py','scripts/x650_cpp_normal_sequence.cpp','scripts/x650_cpp_core_replay.cpp','scripts/probe_x650_cpp_normal_worker.py','scripts/render_x650_cpp_normal.py','tests/unit/test_x650_cpp_normal_qualification.py','tests/unit/test_x650_cpp_normal_audit.py','tests/unit/test_x650_cpp_normal_adapter.py','tests/unit/test_x650_cpp_normal_proofs.py']:
 files['verification_sources/'+rel]=r/rel
manifest=dict(kind='x650_cpp_normal_original_archive_v1',accepted_run='x650_cpp_normal_v1_20261024_172622_46636',simulation_only=True,physical_certificate_sha256=hashlib.sha256((b/'normal_audit_v1/report.json').read_bytes()).hexdigest(),scope='Complete original accepted ordinary physical flight, immutable software proof and retained failed software setups; recorded presentation is delivered separately. No fast or hardware qualification.',files=[])
out=b/'normal_full_raw_v1.zip'
with zipfile.ZipFile(out,'x',zipfile.ZIP_DEFLATED) as z:
 for name,p in sorted(files.items()):
  raw=p.read_bytes();digest=hashlib.sha256(raw).hexdigest();z.writestr(name,raw)
  assert hashlib.sha256(p.read_bytes()).hexdigest()==digest,str(p)
  manifest['files'].append(dict(entry=name,source_path=str(p),bytes=len(raw),sha256=digest))
 z.writestr('archive_manifest.json',json.dumps(manifest,indent=2))
(b/'normal_full_raw_v1_manifest.json').write_text(json.dumps(manifest,indent=2))
receipt=dict(path=str(out),bytes=out.stat().st_size,sha256=hashlib.sha256(out.read_bytes()).hexdigest(),entries=len(files),uncompressed_bytes=sum(f['bytes'] for f in manifest['files']))
(b/'normal_full_raw_v1_receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
