source /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_normal_20261024/normal_environment_v1.sh
while [ ! -f artifacts/cpp_normal_20261024/normal_run_v1.exit ]; do sleep 1; done
set +e
taskset -c 0 nice -n 10 /usr/bin/python3 scripts/audit_x650_cpp_normal.py --launch-dir /root/autodl-tmp/safe-aerial-manipulator-testbed/runs/x650_cpp_normal_launch_20261024_172532_46633 --run-dir /root/autodl-tmp/safe-aerial-manipulator-testbed/runs/x650_cpp_normal_v1_20261024_172622_46636 --output /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_normal_20261024/normal_audit_v1 > artifacts/cpp_normal_20261024/normal_audit_v1.log 2>&1
code=$?
printf '%s\n' "$code" > artifacts/cpp_normal_20261024/normal_audit_v1.exit
exit "$code"
