cd /root/autodl-tmp/safe-aerial-manipulator-testbed
export MUJOCO_GL=egl OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
set +e
taskset -c 0 nice -n 10 /root/autodl-tmp/amsim-venv/bin/python scripts/render_x650_cpp_normal.py --report artifacts/cpp_normal_20261024/normal_audit_v1/report.json --report-sha256 a8588defbd3ce237a04e1403d7f895aecde4008fa4ee4ca78c591ddb711be474 --output artifacts/cpp_normal_20261024/video_v1 > artifacts/cpp_normal_20261024/video_v1.log 2>&1
code=$?
printf '%s\n' "$code" > artifacts/cpp_normal_20261024/video_v1.exit
exit "$code"
