source /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_pipeline_20261024/stream_environment_v2.sh
source /root/autodl-tmp/flyarm_cpp_normal_20261024/install/local_setup.bash
set +e
g++ -std=c++17 -O3 -I ros2_ws/src/flyarm_mpc_cpp/include -I control_packages/x650_wholebody_v1/native -I ros2_ws/src/flyarm_state_cpp/include -I ros2_ws/src/flyarm_control_gateway/include $(pkg-config --cflags jsoncpp) scripts/x650_cpp_normal_sequence.cpp /root/autodl-tmp/x650_cpp_core_scratch_v2/libx650_mpc_core.so -Wl,-rpath,/root/autodl-tmp/x650_cpp_core_scratch_v2 $(pkg-config --libs jsoncpp) -lcrypto -ldl -pthread -o artifacts/cpp_normal_20261024/normal_sequence_v3 > /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_normal_20261024/sequence_build_v3.log 2>&1
code=$?
printf '%s\n' "$code" > /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_normal_20261024/sequence_build_v3.exit
if [ "$code" != 0 ]; then exit "$code"; fi
taskset -c 87 /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_normal_20261024/normal_sequence_v3 /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_normal_20261024/normal_inputs_v1/startup_manifest.json 13c6f59179b70402b2539d7025105950d74d8f68c80c73f458c719c0fc70fb40 /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_normal_20261024/dynamic_raw_v1/case_000.json /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_normal_20261024/sequence_v3 > /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_normal_20261024/sequence_v3.log 2>&1
code=$?
printf '%s\n' "$code" > /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_normal_20261024/sequence_v3.exit
if [ "$code" != 0 ]; then exit "$code"; fi
/usr/bin/python3 scripts/probe_x650_cpp_normal_worker.py --sequence /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_normal_20261024/sequence_v3/manifest.json --startup /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_normal_20261024/normal_inputs_v1/startup_manifest.json --worker /root/autodl-tmp/flyarm_cpp_normal_20261024/install/flyarm_mpc_cpp/lib/flyarm_mpc_cpp/isolated_worker --output /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_normal_20261024/worker_ros_v3 > /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_normal_20261024/worker_ros_v3.log 2>&1
code=$?
printf '%s\n' "$code" > /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_normal_20261024/worker_ros_v3.exit
exit "$code"
