source /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_pipeline_20261024/stream_environment_v2.sh
set +e
g++ -std=c++17 -O3 -I ros2_ws/src/flyarm_mpc_cpp/include -I control_packages/x650_wholebody_v1/native -I ros2_ws/src/flyarm_state_cpp/include -I ros2_ws/src/flyarm_control_gateway/include $(pkg-config --cflags jsoncpp) scripts/x650_cpp_normal_sequence.cpp /root/autodl-tmp/x650_cpp_core_scratch_v2/libx650_mpc_core.so -Wl,-rpath,/root/autodl-tmp/x650_cpp_core_scratch_v2 $(pkg-config --libs jsoncpp) -lcrypto -ldl -pthread -o artifacts/cpp_normal_20261024/normal_sequence > /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_normal_20261024/sequence_build_v1.log 2>&1
code=$?
printf '%s\n' "$code" > /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_normal_20261024/sequence_build_v1.exit
exit "$code"
