"""Archive presentation originals after complete decode; never alter physics evidence."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import time
import zipfile

R = Path('/root/autodl-tmp/safe-aerial-manipulator-testbed')
B = R/'artifacts/cpp_normal_20261024'
sys.path.insert(0, str(R/'scripts'))
import render_x650_isolated_validation as visual


def identity(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def main():
    assert (B/'video_v2.exit').read_text().strip() == '0'
    manifest = json.loads((B/'video_v2/replay_manifest.json').read_text())
    assert manifest['complete'] and manifest['video_produced']
    assert manifest['frames'] == 768 and manifest['decoded_video']['full_decode_passed']
    assert manifest['geometry']['visual_mesh_count'] == 281
    assert manifest['geometry']['mesh_decimation'] is False
    assert manifest['render_quality']['profile'] == 'software_fast_v1'
    assert manifest['effective_offscreen_samples'] == 0
    video = Path(manifest['video']['path'])
    assert identity(video) == manifest['video']
    decode = B/'video_v2/full_decode.framemd5'
    stderr = B/'video_v2/full_decode.stderr'
    ffmpeg = manifest['input_hashes']['ffmpeg_executable']
    assert identity(Path(ffmpeg['path'])) == ffmpeg
    cmd = [ffmpeg['path'], '-v', 'error', '-xerror', '-i', str(video),
           '-map', '0:v:0', '-an', '-f', 'framemd5', '-']
    with decode.open('x') as out, stderr.open('x') as error:
        result = subprocess.run(cmd, stdout=out, stderr=error)
    assert result.returncode == 0
    decoded = visual.decoded_video_contract(decode.read_text(), 768)
    raw_decode = dict(**decoded, command=cmd, returncode=result.returncode,
                      video=identity(video), decoded_frames=identity(decode), stderr=identity(stderr))
    (B/'video_v2/full_decode.json').write_text(json.dumps(raw_decode, indent=2)+'\n')
    sources = B/'presentation_sources_v2'
    sources.mkdir()
    process = json.loads((B/'video_v2_process.json').read_text())
    source_rows = []
    for name, expected in process['source_hashes'].items():
        original = R/'scripts'/name
        assert identity(original)['sha256'] == expected
        copy = sources/name
        copy.write_bytes(original.read_bytes())
        source_rows.append({'original': identity(original), 'preserved': identity(copy)})
    v1 = B/'video_v1/X650_normal_CPP_MPC.mp4'
    mapping = dict(scope='Presentation-only quality/parallel rendering; no physics rerun or mesh decimation',
                   new_sources=source_rows,
                   original_sources=identity(B/'presentation_sources_v1/manifest.json'),
                   old_video_partial_not_deliverable=identity(v1) if v1.exists() else None,
                   old_video_exit=(B/'video_v1.exit').read_text().strip(),
                   new_video=identity(video),
                   quality=manifest['render_quality'],
                   source_certificate=manifest['input_hashes']['report'])
    (sources/'mapping.json').write_text(json.dumps(mapping, indent=2)+'\n')
    selected=[]
    for name in ('video_v2','preview_v2','presentation_sources_v1','presentation_sources_v2'):
        selected.extend(p for p in (B/name).iterdir() if p.is_file())
    selected.extend(B/name for name in ('video_v2.sh','video_v2_process.json','video_v2.log','video_v2.exit',
        'preview_v2_process.json','preview_v2.log','video_v1.exit','gpu_render_probe_v1.json',
        'nvidia_egl560_vendor.json','preview_profile_v1.log','archive_media_v2.py'))
    archive = B/'normal_media_v2.zip'
    rows=[]
    with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED) as output:
        for path in sorted(selected):
            item = identity(path)
            item['entry'] = path.relative_to(B).as_posix()
            assert 'render_geometry' not in path.parts
            output.write(path, item['entry'])
            rows.append(item)
        package = dict(kind='x650_cpp_normal_media_archive_v2', complete=True,
            file_count=len(rows), files=rows, video=identity(video), full_decode=raw_decode,
            excluded='Generated render_geometry cache and incomplete old v1 video; original physics mesh SHA remains bound',
            physical_rerun=False, source_certificate=manifest['input_hashes']['report'])
        payload=json.dumps(package,indent=2)+'\n'
        output.writestr('archive_manifest.json',payload)
    (B/'normal_media_v2_manifest.json').write_text(payload)
    receipt=dict(archive=identity(archive),manifest=identity(B/'normal_media_v2_manifest.json'),
                 verified_at_unix=time.time(),file_count=len(rows),video=identity(video),complete=True)
    (B/'normal_media_v2_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))


if __name__ == '__main__':
    main()
