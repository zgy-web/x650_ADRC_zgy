#!/bin/bash
set -eo pipefail
version="$1"
root=/root/autodl-tmp/safe-aerial-manipulator-testbed
base="$root/artifacts/cpp_interval_hard_20261026"
source "$root/artifacts/cpp_fast_20261024/fast_environment_v1.sh"
colcon --log-base "$base/ros_$version/log" build --base-paths "$base/source_$version/ros2_ws/src/flyarm_mpc_cpp" --build-base "$base/ros_$version/build" --install-base "$base/ros_$version/install" --cmake-args -DCMAKE_BUILD_TYPE=Release -DX650_NATIVE_SOURCE_DIR="$base/source_$version/control_packages/x650_wholebody_v1/native" -DX650_MPC_CORE_LIBRARY="$base/build_$version/libx650_mpc_core.so" -DBUILD_TESTING=ON > "$base/ros_$version.log" 2>&1
ctest --test-dir "$base/ros_$version/build/flyarm_mpc_cpp" --output-on-failure >> "$base/ros_$version.log" 2>&1
tail -n 24 "$base/ros_$version.log"
