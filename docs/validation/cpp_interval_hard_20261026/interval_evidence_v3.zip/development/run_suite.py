from pathlib import Path
import hashlib,json,subprocess,sys,os
A=Path('/root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_interval_hard_20261026')
B=A.parent/'cpp_safety_margin_20261026'
v=sys.argv[1]; seq=sys.argv[2] if len(sys.argv)>2 else '1,378,379,380,383,384,428,429'
old=json.loads((B/'margin429_v1.raw.json').read_text())
p=old['loaded_code']['predictor']; build=A/f'build_{v}'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cmd=['/usr/bin/python3',str(A/f'source_{v}/scripts/run_x650_interval_regression.py'),'--original-report',str(B/'reconstruction429_v1/report.json'),'--executable',str(build/'interval_replay'),'--predictor',p['path'],'--output',str(A/f'regression_{v}'),'--sequences',seq,'--core-sha256',sha(build/'libx650_mpc_core.so'),'--optimization-sha256',sha(build/'libx650_optimization.so'),'--baseline-raw-dir',str(B/'fixed_calls_v1')]
env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None);env.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
with (A/f'regression_{v}.log').open('x') as out:r=subprocess.run(cmd,env=env,stdout=out,stderr=subprocess.STDOUT)
print('returncode',r.returncode)
report=json.loads((A/f'regression_{v}/report.json').read_text())
print(json.dumps({k:v for k,v in report.items() if k!='rows'},indent=2))
print(json.dumps([{k:r.get(k) for k in ['sequence','passed','error','core_error','core_ms','interval_rows']} for r in report['rows'] if not r['passed']],indent=2))
