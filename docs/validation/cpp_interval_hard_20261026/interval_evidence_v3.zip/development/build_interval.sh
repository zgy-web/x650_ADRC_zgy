#!/bin/bash
set -euo pipefail
version="$1"
base=/root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_interval_hard_20261026
cd "$base"
test ! -d "source_$version"
python3 -m zipfile -e "source_$version.zip" "source_$version"
cmake -S "source_$version/control_packages/x650_wholebody_v1/native" -B "build_$version" -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=ON > "build_$version.log" 2>&1
cmake --build "build_$version" -j4 >> "build_$version.log" 2>&1
ctest --test-dir "build_$version" --output-on-failure >> "build_$version.log" 2>&1
c++ -std=c++17 -O2 "source_$version/scripts/x650_cpp_recovery_replay.cpp" -I"source_$version/control_packages/x650_wholebody_v1/native" -I"source_$version/control_packages/x650_wholebody_v1/benchmark/include" -I/usr/include/jsoncpp -L"build_$version" -Wl,-rpath,"$base/build_$version" -lx650_mpc_core -ljsoncpp -lcrypto -ldl -o "build_$version/interval_replay" > "build_replay_$version.log" 2>&1
tail -n 16 "build_$version.log"
