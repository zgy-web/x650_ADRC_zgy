from pathlib import Path
import json,subprocess,sys,os
A=Path('/root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_interval_hard_20261026')
B=A.parent/'cpp_safety_margin_20261026'
version=sys.argv[1]
old=json.loads((B/'margin429_v1.raw.json').read_text())
p=old['loaded_code']['predictor']
out=A/f'interval429_{version}.raw.json'
assert not out.exists()
cmd=[str(A/f'build_{version}/interval_replay'),p['path'],p['sha256'],str(B/'reconstruction429_v1/000429.input.json'),old['input_sha256'],str(out)]
env=os.environ.copy();env.pop('LD_LIBRARY_PATH',None)
env.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
r=subprocess.run(cmd,capture_output=True,text=True,env=env,timeout=30)
(A/f'interval429_{version}.execution.json').write_text(json.dumps(dict(command=cmd,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr),indent=2))
d=json.loads(out.read_text());a=d['diagnostics']
print(json.dumps(dict(returned=d['returned'],error=d['error'],ms=a['compute_ms'],subproblems=a['subproblems'],rows=a.get('interval_rows'),envelope=a.get('candidate_envelope'),repairs=[{k:v for k,v in x.items() if k not in ('points','centre_plan','risk_margin','trigger_points')}|dict(points=len(x['points']),triggers=x.get('trigger_points')) for x in a['interval_repairs']],memory_unchanged=d['memory_unchanged']),indent=2))
