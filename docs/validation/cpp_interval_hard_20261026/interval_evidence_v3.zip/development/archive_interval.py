from pathlib import Path
import hashlib,json,sys,zipfile,shutil
A=Path('/root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_interval_hard_20261026');B=A.parent/'cpp_safety_margin_20261026';v=sys.argv[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report=json.loads((A/f'regression_{v}/report.json').read_text())
assert report['passed'] and report['complete']
delivery=A/f'delivery_{v}';delivery.mkdir()
files={}
def add(p,arc):
 if p.is_file():files[arc]=p
for name in [f'source_{v}',f'regression_{v}']:
 for p in (A/name).rglob('*'):
  if '__pycache__' not in p.parts:add(p,p.relative_to(A).as_posix())
for p in (B/'reconstruction429_v1').glob('*.input.json'):add(p,'original_inputs/'+p.name)
add(B/'reconstruction429_v1/report.json','original_inputs/reconstruction_report.json')
for p in (B/'fixed_calls_v1').glob('*.raw.json'):add(p,'previous_fixed_baseline/'+p.name)
for p in A.glob('*'):
 if p.suffix in ('.json','.log','.py','.sh') or p.name in ('source_v1.zip','source_v2.zip'):add(p,'development/'+p.name)
for p in (A/f'build_{v}').glob('*.so'):add(p,'binaries/'+p.name)
add(A/f'build_{v}/interval_replay','binaries/interval_replay')
add(A/f'build_{v}/Testing/Temporary/LastTest.log','tests/native_LastTest.log')
add(A/f'ros_{v}/build/flyarm_mpc_cpp/Testing/Temporary/LastTest.log','tests/ros_LastTest.log')
add(A/f'ros_{v}/install/flyarm_mpc_cpp/lib/flyarm_mpc_cpp/isolated_worker','binaries/isolated_worker')
old=json.loads((B/'margin429_v1.raw.json').read_text())
add(Path(old['loaded_code']['predictor']['path']),'binaries/original_ts20_prediction.so')
manifest=[dict(member=k,source=str(p),bytes=p.stat().st_size,sha256=sha(p)) for k,p in sorted(files.items())]
archive=delivery/f'interval_evidence_{v}.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
 for item in manifest:z.write(files[item['member']],item['member'])
 z.writestr('archive_manifest.json',json.dumps(manifest,indent=2))
(delivery/'archive_manifest.json').write_text(json.dumps(manifest,indent=2))
for source,name in [(A/f'regression_{v}/report.json','regression_report.json'),(A/f'regression_{v}/000429/raw.json','recovered429.raw.json'),(A/f'regression_{v}/000429/audit.json','recovered429.audit.json'),(A/f'regression_{v}/000429/canonical_proof.json','recovered429.canonical_proof.json'),(B/'reconstruction429_v1/000429.input.json','000429.input.json'),(A/f'build_{v}.log','native_tests.log'),(A/f'ros_{v}.log','ros_tests.log'),(A/f'audit_tests_{v}.log','audit_tests.log')]:
 shutil.copyfile(source,delivery/name)
rows=report['rows'];failure=next(r for r in rows if r['sequence']==429)
summary=dict(kind='x650_interval_hard_constraint_software_v1',passed=True,closed_loop=False,actuator_io=False,hardware_qualified=False,slack_variables=0,inner_velocity_limits=[.42,.32],source_snapshot_sha256=sha(A/f'source_{v}.zip'),expected_libraries=report['expected_libraries'],calls=len(rows),passed_calls=sum(r['passed'] for r in rows),core_ms_min=min(r['core_ms'] for r in rows),core_ms_max=max(r['core_ms'] for r in rows),interval_calls=[r['sequence'] for r in rows if r.get('interval_rows',0)],normal_exact_calls=[r['sequence'] for r in rows if r.get('normal_path_exact_equivalence',{}).get('passed')],recovered429=failure,archive=dict(name=archive.name,bytes=archive.stat().st_size,sha256=sha(archive),members=len(manifest)+1))
(delivery/'software_summary.json').write_text(json.dumps(summary,indent=2))
(delivery/'delivery_manifest.json').write_text(json.dumps([dict(name=p.name,bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(delivery.iterdir()) if p.is_file()],indent=2))
print(json.dumps(summary,indent=2))
