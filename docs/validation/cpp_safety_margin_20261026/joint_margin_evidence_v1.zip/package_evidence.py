from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

r=Path('/root/autodl-tmp/safe-aerial-manipulator-testbed')
a=r/'artifacts/cpp_safety_margin_20261026'
out=a/'delivery_v1'
out.mkdir(exist_ok=False)
test=subprocess.run(['/usr/bin/python3','-m','unittest','discover','-s','tests/unit',
    '-p','test_x650_joint_safety_margin_audit.py','-v'],cwd=r,capture_output=True,text=True)
(a/'audit_tests_v1.log').write_text(test.stdout+test.stderr)
assert test.returncode==0
files={}
def add(p,n):
    assert p.is_file() and n not in files
    files[n]=p
for sub in ('recording429_v1','reconstruction429_v1','fixed_calls_v1','source_v1'):
    for p in sorted((a/sub).rglob('*')):
        if p.is_file():add(p,p.relative_to(a).as_posix())
for p in sorted(a.iterdir()):
    if p.is_file() and p.suffix in ('.json','.log','.sh','.py'):add(p,p.name)
for n in ('libx650_mpc_core.so','libx650_optimization.so','margin_replay','test_mpc_core','test_quadprog_identity'):
    add(a/'build_v1'/n,'binaries/'+n)
for n in ('scripts/export_x650_runtime_replay.py','scripts/audit_x650_joint_safety_margin.py',
          'scripts/audit_x650_recovery_replay.py','scripts/x650_cpp_recovery_replay.cpp',
          'scripts/x650_cpp_recovery_sequence.cpp','tests/unit/test_x650_joint_safety_margin_audit.py'):
    add(r/n,'tools/'+n)
for p in sorted((r/'control_packages/x650_wholebody_v1/benchmark/include').rglob('*.hpp')):
    add(p,'tools/'+p.relative_to(r).as_posix())
for p in sorted((a/'python_test_v1/control_packages/x650_wholebody_v1').rglob('*')):
    if p.is_file() and p.suffix in ('.py','.npz') and '__pycache__' not in p.parts:
        add(p,p.relative_to(a).as_posix())
add(a/'python_test_v1/tests/unit/test_x650_joint_safety_margin.py','python_test_v1/tests/unit/test_x650_joint_safety_margin.py')
rows=[]
for n,p in sorted(files.items()):
    data=p.read_bytes();rows.append(dict(member=n,source=str(p),bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
manifest=dict(kind='x650_joint_margin_evidence_v1',scope='offline fixed-input inspection, rejected call and no flight acceptance',files=rows)
(out/'archive_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=out/'joint_margin_evidence_v1.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
    z.write(out/'archive_manifest.json','archive_manifest.json')
    for row in rows:z.write(files[row['member']],row['member'])
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for row in rows:
        data=z.read(row['member']);assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
        assert hashlib.sha256(files[row['member']].read_bytes()).hexdigest()==row['sha256']
delivery=dict(archive=archive.name,bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
              member_count=len(rows)+1,all_source_and_zip_member_hashes_verified=True,crc_verified=True,
              physical_validation=False,margin_fix_solved_429=False)
(out/'delivery_manifest.json').write_text(json.dumps(delivery,indent=2)+'\n')
print(json.dumps(delivery))
