set -euo pipefail
cd /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_safety_margin_20261026/python_test_v1
/usr/bin/python3 -m unittest discover -s tests/unit -p test_x650_joint_safety_margin.py -v
/usr/bin/python3 -m unittest discover -s control_packages/x650_wholebody_v1/tests -p test_native_optimization.py -v
/usr/bin/python3 -m unittest discover -s control_packages/x650_wholebody_v1/tests -p test_ts20_mpc.py -v
