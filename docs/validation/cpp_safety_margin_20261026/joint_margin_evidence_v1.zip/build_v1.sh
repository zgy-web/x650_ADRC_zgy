#!/bin/bash
set -euo pipefail
cmake -S /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_safety_margin_20261026/source_v1/control_packages/x650_wholebody_v1/native -B /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_safety_margin_20261026/build_v1 -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=ON
cmake --build /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_safety_margin_20261026/build_v1 -j 4
ctest --test-dir /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_safety_margin_20261026/build_v1 --output-on-failure
