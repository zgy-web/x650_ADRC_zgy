"""Same captured QPs, alternating native libraries; no controller or ROS output."""
from pathlib import Path
import ctypes,hashlib,json,os,sys,time
import numpy as np
R=Path('/root/autodl-tmp/safe-aerial-manipulator-testbed')
B=R/'artifacts/isolated_live_20261024/identity_qp_scratch_v1'
sys.path.insert(0,str(R/'control_packages/x650_wholebody_v1'))
from x650_wholebody.native_optimization import NativeOptimization
from x650_wholebody.mpc import MpcController
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths={'before':Path('/root/autodl-tmp/x650_native_optimization_build_v3/libx650_optimization.so'),
       'identity':B/'build/libx650_optimization.so'}
solvers={name:NativeOptimization(p,sha(p)) for name,p in paths.items()}
cpu=ctypes.CDLL(None).sched_getcpu;cpu.restype=ctypes.c_int
rows=[];cases={};comparisons=[]
for sequence in (1054,1055,1056):
    path=B/f'original_replay/hold25_round{sequence}_qp0.npz'
    with np.load(path) as saved:
        p={k:saved[k].copy() for k in ('H','g','C','lo','hi')}
        count=int(saved['max_iterations']);original=saved['solution'].copy()
    result={name:solver.solve(p,count) for name,solver in solvers.items()}
    a,b=result['before'][0],result['identity'][0]
    assert np.array_equal(a,b) and np.array_equal(a,original)
    assert result['before'][1:]==result['identity'][1:]
    independent=MpcController._quality(p,b)
    assert independent['primal_violation']<=2e-7
    comparisons.append({'sequence':sequence,'qp_sha256':sha(path),'solution_bitwise_equal':a.tobytes()==b.tobytes(),
                        'matches_original_replay_bitwise':a.tobytes()==original.tobytes(),
                        'objective_before':float(.5*a@p['H']@a+p['g']@a),
                        'objective_identity':float(.5*b@p['H']@b+p['g']@b),
                        'quality_before':result['before'][1],'quality_identity':result['identity'][1],
                        'independent_original_row_quality':independent,'shape':[len(a),len(p['C'])]})
    cases[sequence]=(p,count)

def frequency(core):
    p=Path(f'/sys/devices/system/cpu/cpu{core}/cpufreq/scaling_cur_freq')
    try:return int(p.read_text())
    except OSError:return None

def pair(sequence,index,mode):
    p,count=cases[sequence]
    order=('before','identity') if index%2==0 else ('identity','before')
    core=cpu();freq=frequency(core)
    for name in order:
        c0=cpu();c=time.thread_time_ns();w=time.monotonic_ns()
        result=solvers[name].solve(p,count)
        wall=time.monotonic_ns()-w;thread=time.thread_time_ns()-c;c1=cpu()
        rows.append({'sequence':sequence,'pair':index,'mode':mode,'backend':name,
                     'wall_ns':wall,'thread_cpu_ns':thread,'cpu_begin':c0,'cpu_end':c1,
                     'frequency_before_pair_khz':freq,'frequency_observed_core':core})

for sequence in cases:
    time.sleep(.5)
    for i in range(3):pair(sequence,i,'first_three_after_idle')
    for i in range(100):pair(sequence,i,'continuous_alternating')
    due=time.monotonic()+.5
    for i in range(30):
        pause=due-time.monotonic()
        if pause>0:time.sleep(pause)
        due+=.02
        pair(sequence,i,'20ms_absolute_paced_pairs')

summary=[]
for sequence in cases:
    for mode in ('first_three_after_idle','continuous_alternating','20ms_absolute_paced_pairs'):
        entry={'sequence':sequence,'mode':mode}
        for backend in solvers:
            selected=[r for r in rows if r['sequence']==sequence and r['mode']==mode and r['backend']==backend]
            entry[backend]={key:{'median':float(np.median([r[key]/1e6 for r in selected])),
                                   'p95':float(np.percentile([r[key]/1e6 for r in selected],95)),
                                   'max':float(max(r[key]/1e6 for r in selected))}
                            for key in ('wall_ns','thread_cpu_ns')}
            entry[backend]['cores']=sorted({r['cpu_begin'] for r in selected}|{r['cpu_end'] for r in selected})
        entry['median_wall_saving_ms']=entry['before']['wall_ns']['median']-entry['identity']['wall_ns']['median']
        summary.append(entry)
report={'kind':'hold25_identity_qp_alternating_v1','physical_run':False,
        'affinity':sorted(os.sched_getaffinity(0)),'library_sha256':{str(p):sha(p) for p in paths.values()},
        'source_sha256':{str(p.relative_to(B)):sha(p) for p in (B/'native').rglob('*') if p.is_file()},
        'interpretation':'Same three original reconstructed QPs, alternating order within pairs; unchanged original-row gates. Microbenchmark only, no flight or whole-engine deadline claim. Frequency samples are read outside timed call and are observations, not guaranteed in-call frequency.',
        'comparisons':comparisons,'summary':summary,'timings':rows}
(B/'comparison.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps({'report':str(B/'comparison.json'),'comparisons':comparisons,'summary':summary},indent=2))
