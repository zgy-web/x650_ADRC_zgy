"""Offline original-CDR replay and isolated QP comparison; never starts ROS nodes."""
from pathlib import Path
from types import SimpleNamespace
import argparse,base64,ctypes,hashlib,json,os,sys,time
import numpy as np

ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True)
args=ap.parse_args();args.output.mkdir(parents=True,exist_ok=False)
R=Path('/root/autodl-tmp/safe-aerial-manipulator-testbed')
sys.path[:0]=[str(R),str(R/'ros2_ws/src/flyarm_mpc_reference'),str(R/'control_packages/x650_wholebody_v1')]
from rclpy.serialization import deserialize_message
from flyarm_control_interfaces.msg import ControlSnapshot,ControlProposal
from flyarm_mpc_reference.live_factory import create_live_engine
from flyarm_mpc_reference.diagnostic_channel import CaptureAdapter
live=R/'runs/x650_isolated_live_v1_20261024_131702_20177/isolated_live'
task=R/'runs/x650_isolated_launch_20261024_131614_20176/task.json'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
libc=ctypes.CDLL(None);libc.sched_getcpu.restype=ctypes.c_int
start=json.loads((live/'live_start.json').read_text())
engine=create_live_engine(R,task,sha(task),live/'initialization.json',sha(live/'initialization.json'),start['session_id'],start['epoch'])
engine.begin_live(SimpleNamespace(**start));capture=CaptureAdapter(engine.adapter);engine.adapter=capture
allocator=capture.adapter.allocator;kernel=allocator.native_optimization
phases={};sequence=0;problem_capture=[]

def wrap(obj,name,label):
    original=getattr(obj,name)
    def invoke(*a,**kw):
        if sequence<1050:return original(*a,**kw)
        w=time.monotonic_ns();c=time.thread_time_ns();cpu=libc.sched_getcpu()
        try:return original(*a,**kw)
        finally:
            row=phases.setdefault(label,[])
            row.append({'wall_ms':(time.monotonic_ns()-w)/1e6,'cpu_ms':(time.thread_time_ns()-c)/1e6,
                        'cpu_begin':cpu,'cpu_end':libc.sched_getcpu()})
    setattr(obj,name,invoke)

original_solve=kernel.solve
def solve(problem,max_iterations):
    result=original_solve(problem,max_iterations)
    if sequence>=1054:
        problem_capture.append({**{k:np.array(problem[k],copy=True) for k in ('H','g','C','lo','hi','scale','warm') if k in problem},
                                'solution':result[0].copy(),'quality':result[1],
                                'max_iterations':max_iterations,'exact_center':result[2]})
    return result
kernel.solve=solve
for obj,name,label in ((engine,'_decode','decode'),(capture.adapter,'step','adapter'),
                       (allocator,'step','allocator'),(allocator,'_joint_prediction','joint_prediction'),
                       (kernel,'assemble','assemble_including_joint_prediction'),(kernel,'call','native_call'),
                       (kernel,'solve','qp'),(allocator,'_validate_candidate','candidate'),
                       (kernel,'endpoint','endpoint'),(capture,'complete_diagnostic','deferred_diagnostics')):
    wrap(obj,name,label)

fields=('position_reference_enu','velocity_feedforward_enu','acceleration_feedforward_enu','base_velocity_target','joint_velocity')
rows=[];max_error=0.;all_pass=True;next_due=time.monotonic()+.5
with (live/'recording/diagnostics.jsonl').open() as source:
    for line in source:
        data=json.loads(line);sequence=int(data['sequence'])
        snapshot=deserialize_message(base64.b64decode(data['snapshot_cdr']['base64']),ControlSnapshot)
        original=deserialize_message(base64.b64decode(data['proposal_cdr']['base64']),ControlProposal)
        pause=next_due-time.monotonic()
        if pause>0:time.sleep(pause)
        next_due+=.02
        snapshot.issued_monotonic_ns=time.monotonic_ns()
        phases.clear();problem_capture.clear()
        cpu=libc.sched_getcpu();w=time.monotonic_ns();c=time.thread_time_ns()
        proposal=engine.process(snapshot,ControlProposal)
        engine_wall=(time.monotonic_ns()-w)/1e6;engine_cpu=(time.thread_time_ns()-c)/1e6
        capture.complete_diagnostic(sequence)
        delta=max(float(np.max(abs(np.asarray(getattr(proposal,f))-getattr(original,f)))) for f in fields)
        max_error=max(max_error,delta)
        if sequence>=1050 or proposal.status:
            row={'sequence':sequence,'status':int(proposal.status),'engine_wall_ms':engine_wall,
                 'engine_cpu_ms':engine_cpu,'cpu_begin':cpu,'cpu_end':libc.sched_getcpu(),
                 'command_max_abs_error':delta,'phases':dict(phases),
                 'recorded_solve_ms':data['diagnostic'].get('solve_ms'),
                 'replay_solve_ms':capture.diagnostic.get('solve_ms') if capture.diagnostic else None,
                 'error':engine.last_error if proposal.status else None,'qps':[]}
            for j,p in enumerate(problem_capture):
                path=args.output/f'hold25_round{sequence}_qp{j}.npz'
                quality=p.pop('quality');np.savez_compressed(path,**p)
                row['qps'].append({'path':str(path),'sha256':sha(path),'quality':quality,
                                   'exact_center':bool(p['exact_center'])})
            rows.append(row)
        if proposal.status:all_pass=False;break
report={'kind':'hold25_original_input_tail_qp_v1','physical_run':False,
        'input_policy':'Sequential original snapshots 1..1056 from actual LiveStart and initialization; only monotonic issue time rebased. No simulated or actual commands are sent.',
        'capture':'Original pre-solve matrices reconstructed by current sealed production engine; copies only after solve at tail 1054..1056. Phase observations only 1050..1056.',
        'pacing':'20 ms absolute schedule after .5 s initial idle; late calls do not reset schedule; natural GC unchanged',
        'completed':sequence,'all_accepted':all_pass,'max_command_error':max_error,'affinity':sorted(os.sched_getaffinity(0)),
        'inputs':{str(p):sha(p) for p in (task,live/'initialization.json',live/'live_start.json',live/'recording/diagnostics.jsonl')},
        'libraries':{str(p):sha(p) for p in (Path('/root/autodl-tmp/x650_native_optimization_build_v3/libx650_optimization.so'),Path('/root/autodl-tmp/libts20_prediction_v3.so'))},
        'rows':rows}
(args.output/'report.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps({'report':str(args.output/'report.json'),'completed':sequence,'accepted':all_pass,'max_error':max_error,'tail':rows[-3:]},indent=2))
