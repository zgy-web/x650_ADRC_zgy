set -e
source /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_pipeline_20261024/stream_environment_v2.sh
source /root/autodl-tmp/flyarm_cpp_fast_20261024/install/local_setup.bash
cd /root/autodl-tmp/safe-aerial-manipulator-testbed
g++ -std=c++17 -O3 scripts/x650_cpp_fast_sequence.cpp -Iros2_ws/src/flyarm_mpc_cpp/include -Iros2_ws/src/flyarm_state_cpp/include -Icontrol_packages/x650_wholebody_v1/native $(pkg-config --cflags jsoncpp) -L/root/autodl-tmp/x650_cpp_core_scratch_v2 -L/root/autodl-tmp/x650_native_optimization_build_v4 -Wl,-rpath,/root/autodl-tmp/x650_cpp_core_scratch_v2 -Wl,-rpath,/root/autodl-tmp/x650_native_optimization_build_v4 -lx650_mpc_core -lx650_optimization $(pkg-config --libs jsoncpp) -lcrypto -ldl -pthread -o artifacts/cpp_fast_20261024/fast_sequence
taskset -c 0 nice -n 10 /usr/bin/python3 scripts/validate_x650_cpp_fast_reference.py --probe /root/autodl-tmp/flyarm_cpp_fast_20261024/build/flyarm_mpc_cpp/trajectory_probe --output artifacts/cpp_fast_20261024/reference_v1 > artifacts/cpp_fast_20261024/reference_v1.log 2>&1
printf 0 > artifacts/cpp_fast_20261024/reference_sequence_build_v1.exit
