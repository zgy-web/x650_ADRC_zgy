source /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_pipeline_20261024/stream_environment_v2.sh
source /root/autodl-tmp/flyarm_cpp_fast_20261024/install/local_setup.bash
cd /root/autodl-tmp/safe-aerial-manipulator-testbed
set +e
taskset -c 87 /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_fast_20261024/fast_sequence /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_fast_20261024/fast_inputs_v1/startup_manifest.json 429e4b27f63e0a969e9dfab64e82c5845b24f174d02f16aa641a46cba3edac48 /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_fast_20261024/dynamic_raw_v1/case_000.json /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_fast_20261024/sequence_v1 > artifacts/cpp_fast_20261024/sequence_v1.log 2>&1
code=$?
printf '%s
' "$code" > artifacts/cpp_fast_20261024/sequence_v1.exit
if [ "$code" != 0 ]; then exit "$code"; fi
/usr/bin/python3 scripts/probe_x650_cpp_fast_worker.py --sequence /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_fast_20261024/sequence_v1/manifest.json --startup /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_fast_20261024/fast_inputs_v1/startup_manifest.json --worker /root/autodl-tmp/flyarm_cpp_fast_20261024/install/flyarm_mpc_cpp/lib/flyarm_mpc_cpp/isolated_worker --output /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_fast_20261024/worker_ros_v1 --domain-id 222 > artifacts/cpp_fast_20261024/worker_ros_v1.log 2>&1
code=$?
printf '%s
' "$code" > artifacts/cpp_fast_20261024/worker_ros_v1.exit
exit "$code"
