from pathlib import Path
import json,subprocess
r=Path('/root/autodl-tmp/safe-aerial-manipulator-testbed');b=r/'artifacts/cpp_fast_20261024'
l=r/'runs/x650_cpp_fast_launch_20261024_200610_52114'
assert (b/'fast_run_v1.exit').read_text().strip()=='0'
a=json.loads((l/'launch.json').read_text());assert a['complete'] is True and len(a['run_directories'])==1
run=Path(a['run_directories'][0]);cmd=['/usr/bin/python3','scripts/audit_x650_cpp_fast.py','--launch-dir',str(l),'--run-dir',str(run),'--output',str(b/'fast_audit_v1')]
(b/'physical_run_identity_v1.json').write_text(json.dumps(dict(launch=str(l),run=str(run),audit_command=cmd),indent=2))
with (b/'fast_audit_v1.log').open('x') as stream: code=subprocess.run(cmd,cwd=r,stdout=stream,stderr=subprocess.STDOUT).returncode
(b/'fast_audit_v1.exit').write_text(str(code)+'\n');raise SystemExit(code)
