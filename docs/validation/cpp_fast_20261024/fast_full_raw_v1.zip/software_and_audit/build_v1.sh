set -e
source /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_pipeline_20261024/stream_environment_v2.sh
cd /root/autodl-tmp/flyarm_cpp_fast_20261024
set +e
colcon build --packages-select flyarm_mpc_cpp --parallel-workers 2 --cmake-args -DCMAKE_BUILD_TYPE=Release -DX650_NATIVE_SOURCE_DIR=/root/autodl-tmp/safe-aerial-manipulator-testbed/control_packages/x650_wholebody_v1/native -DX650_MPC_CORE_LIBRARY=/root/autodl-tmp/x650_cpp_core_scratch_v2/libx650_mpc_core.so > /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_fast_20261024/build_v1.log 2>&1
code=$?
if [ "$code" = 0 ]; then ctest --test-dir build/flyarm_mpc_cpp --output-on-failure >> /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_fast_20261024/build_v1.log 2>&1; code=$?; fi
printf '%s\n' "$code" > /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_fast_20261024/build_v1.exit
exit "$code"
