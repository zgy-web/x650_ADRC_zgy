source /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_fast_20261024/fast_environment_v1.sh
set +e
/usr/bin/python3 simulations/x650_cpp_fast_v1/launch.py --task /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_fast_20261024/fast_inputs_v1/task.json --startup-manifest /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_fast_20261024/fast_inputs_v1/startup_manifest.json --startup-sha256 429e4b27f63e0a969e9dfab64e82c5845b24f174d02f16aa641a46cba3edac48 --qualification-manifest /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_fast_20261024/fast_inputs_v1/qualification_manifest.json --protocol /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_fast_20261024/fast_inputs_v1/protocol.json > /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_fast_20261024/fast_run_v1.log 2>&1
code=$?
printf '%s\n' "$code" > /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_fast_20261024/fast_run_v1.exit
exit "$code"
