from pathlib import Path
import hashlib,json,time,zipfile,sys
r=Path('/root/autodl-tmp/safe-aerial-manipulator-testbed');b=r/'artifacts/cpp_fast_20261024'
launch=r/'runs/x650_cpp_fast_launch_20261024_200610_52114';run=r/'runs/x650_cpp_fast_v1_20261024_200653_52118'
audit_path=b/'fast_audit_v1/report.json'
for attempt in range(900):
 if (b/'fast_audit_v1.exit').exists():break
 time.sleep(1.)
else:raise TimeoutError('No complete fast audit within 900 seconds; no archive produced')
assert (b/'fast_audit_v1.exit').read_text().strip()=='0','Independent audit failed; no archive produced'
audit=json.loads(audit_path.read_text());assert all(audit.get(k) is True for k in ('passed','complete','certificate','physical_acceptance'))
record=json.loads((launch/'launch.json').read_text());assert all(record.get(k) is True for k in ('complete','runtime_closed','sources_unchanged','runtime_binaries_unchanged','launch_inputs_unchanged'))
assert record['exit_code']==0 and record['run_directories']==[str(run)]
assert not (r/'.amsim/runtime.json').exists()
meta=json.loads((run/'controller_metadata.json').read_text());assert all(meta.get(k) is True for k in ('complete','landed_and_disarmed','diagnostic_parameters_restored'))
assert meta.get('diagnostic_restore_pending') is False

def hashfile(p):return hashlib.sha256(p.read_bytes()).hexdigest()
original_identities=audit.get('artifact_identities',[]);assert original_identities
# Verify all original accepted-certificate source files before packaging, even
# shared dependencies outside this archive's declared flight/software scope.
for item in original_identities:
 p=Path(item['path']);assert p.is_file() and hashfile(p)==item['sha256'],str(p)
 if 'bytes' in item:assert p.stat().st_size==item['bytes'],str(p)

folders={'accepted/launch':launch,'accepted/run':run,'worker_build_sources':Path('/root/autodl-tmp/flyarm_cpp_fast_20261024/src/flyarm_mpc_cpp')}
files={prefix+'/'+p.relative_to(folder).as_posix():p for prefix,folder in folders.items() for p in folder.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
exclude_files={'fast_full_raw_v1.zip','fast_full_raw_v1_manifest.json','fast_full_raw_v1_receipt.json','archive_fast_v1.log','archive_fast_v1.exit','archive_driver_v1.log','archive_driver_v1.exit'}
exclude_suffixes={'.mp4','.mkv','.avi','.mov','.png','.jpg','.jpeg','.gif','.pdf'}
exclude_output_prefixes=('video_','preview_','plots_','media_','presentation_')
excluded=[]
for p in b.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(b)
 parts=tuple(x.lower() for x in rel.parts)
 reason=None
 if '__pycache__' in parts:reason='Python cache'
 elif p.name in exclude_files:reason='Archive outputs and active archive logs'
 elif p.suffix.lower() in exclude_suffixes:reason='Generated presentation media/plot asset'
 elif any(x.startswith(('video_','preview_','plots_','media_')) or ('geometry' in x and 'cache' in x) for x in parts[:-1]):reason='Presentation/plot/geometry output directory'
 elif p.suffix in {'.log','.exit','.json','.zip'} and p.name.startswith(exclude_output_prefixes):reason='Separate or potentially active presentation output'
 if reason:excluded.append(dict(path=str(p),reason=reason));continue
 files['software_and_audit/'+rel.as_posix()]=p
verification=[
 'scripts/audit_x650_cpp_fast.py','scripts/audit_x650_cpp_fast_source.py','scripts/audit_x650_cpp_normal.py','scripts/audit_x650_cpp_normal_source.py',
 'scripts/audit_x650_cpp_hold.py','scripts/audit_x650_cpp_source.py','scripts/audit_x650_streaming_consumption.py',
 'scripts/export_x650_cpp_fast_inputs.py','scripts/validate_x650_cpp_fast_reference.py','scripts/validate_x650_cpp_pipeline.py',
 'scripts/x650_cpp_fast_sequence.cpp','scripts/x650_cpp_core_replay.cpp','scripts/probe_x650_cpp_fast_worker.py',
 'scripts/render_x650_cpp_fast.py','scripts/plot_x650_cpp_fast.py','scripts/render_x650_cpp_normal.py',
 'tests/unit/test_x650_cpp_fast_qualification.py','tests/unit/test_x650_cpp_fast_audit.py','tests/unit/test_x650_cpp_fast_adapter.py','tests/unit/test_x650_cpp_fast_proofs.py']
missing_optional=[]
for rel in verification:
 p=r/rel
 if p.is_file():files['verification_sources/'+rel]=p
 else:missing_optional.append(rel)
assert len(files)>1000
manifest=dict(kind='x650_cpp_fast_original_archive_v1',accepted_run=run.name,accepted_launch=launch.name,simulation_only=True,
 physical_certificate_sha256=hashfile(audit_path),original_certificate_artifact_count=len(original_identities),original_certificate_artifacts_verified=True,
 scope='Complete stopped accepted fast physical simulation, immutable software proofs and retained prior software settings, commands and audit records. Recorded presentation is delivered separately. No hardware qualification.',
 excluded=excluded,verification_sources_absent=missing_optional,files=[])
out=b/'fast_full_raw_v1.zip';assert not out.exists()
with zipfile.ZipFile(out,'x',zipfile.ZIP_DEFLATED) as z:
 for name,p in sorted(files.items()):
  raw=p.read_bytes();digest=hashlib.sha256(raw).hexdigest();z.writestr(name,raw)
  assert hashfile(p)==digest,str(p)
  manifest['files'].append(dict(entry=name,source_path=str(p),bytes=len(raw),sha256=digest))
 z.writestr('archive_manifest.json',json.dumps(manifest,indent=2))
manifest_path=b/'fast_full_raw_v1_manifest.json';manifest_path.write_text(json.dumps(manifest,indent=2))
# Independent readback of every original ZIP entry, embedded manifest and source.
with zipfile.ZipFile(out) as z:
 assert len(z.namelist())==len(manifest['files'])+1 and len(set(z.namelist()))==len(z.namelist())
 assert json.loads(z.read('archive_manifest.json'))==manifest
 for item in manifest['files']:
  data=z.read(item['entry']);assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256'],item['entry']
  assert hashfile(Path(item['source_path']))==item['sha256'],item['source_path']
for item in original_identities:assert hashfile(Path(item['path']))==item['sha256'],item['path']
receipt=dict(path=str(out),bytes=out.stat().st_size,sha256=hashfile(out),entries=len(files),uncompressed_bytes=sum(f['bytes'] for f in manifest['files']),
 manifest_sha256=hashfile(manifest_path),physical_certificate_sha256=manifest['physical_certificate_sha256'],
 all_entries_size_and_sha256_verified=True,all_sources_unchanged_after_write=True,embedded_manifest_exact=True,
 all_original_certificate_artifacts_verified_again=True,original_certificate_artifact_count=len(original_identities),verification_sources_absent=missing_optional)
(b/'fast_full_raw_v1_receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt,indent=2),flush=True)
