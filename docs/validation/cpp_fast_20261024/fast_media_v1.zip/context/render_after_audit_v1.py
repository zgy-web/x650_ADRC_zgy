from pathlib import Path
import json,subprocess,hashlib,os,time
r=Path('/root/autodl-tmp/safe-aerial-manipulator-testbed');b=r/'artifacts/cpp_fast_20261024';report=b/'fast_audit_v1/report.json'
assert (b/'fast_audit_v1.exit').read_text().strip()=='0'
cert=json.loads(report.read_text());assert cert['passed'] is True and cert['physical_acceptance'] is True
assert not (r/'.amsim/runtime.json').exists()
sha=hashlib.sha256(report.read_bytes()).hexdigest();base=['/root/autodl-tmp/amsim-venv/bin/python','scripts/render_x650_cpp_fast.py','--report',str(report),'--report-sha256',sha]
env=dict(os.environ,MUJOCO_GL='egl',LP_NUM_THREADS='8',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
commands=[('plots_v1',base+['--output',str(b/'plots_v1'),'--plots-only']),('video_v1',base+['--output',str(b/'video_v1'),'--quality','software_fast_v1'])]
(b/'render_process_v1.json').write_text(json.dumps(dict(affinity=sorted(os.sched_getaffinity(0)),pid=os.getpid(),commands=commands,source_certificate_sha256=sha,started_unix=time.time()),indent=2))
for name,cmd in commands:
 with (b/(name+'.log')).open('x') as stream: code=subprocess.run(cmd,cwd=r,env=env,stdout=stream,stderr=subprocess.STDOUT).returncode
 (b/(name+'.exit')).write_text(str(code)+'\n')
 if code: raise SystemExit(code)
