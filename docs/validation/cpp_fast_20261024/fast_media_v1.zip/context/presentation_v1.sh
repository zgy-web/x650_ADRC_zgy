source /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_fast_20261024/fast_environment_v1.sh
while [ ! -f /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_fast_20261024/fast_audit_v1.exit ]; do sleep 2; done
taskset -c 0,2,4,6,8,10,12,14 nice -n 10 /usr/bin/python3 /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_fast_20261024/render_after_audit_v1.py
