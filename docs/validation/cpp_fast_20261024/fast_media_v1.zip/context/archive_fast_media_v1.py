from pathlib import Path
import json,hashlib,zipfile
r=Path('/root/autodl-tmp/safe-aerial-manipulator-testbed');b=r/'artifacts/cpp_fast_20261024';v=b/'video_v1'
assert (b/'video_v1.exit').read_text().strip()=='0'
record=json.loads((v/'replay_manifest.json').read_text());assert record['complete'] is True and record['stage']=='fast' and record['video_produced'] is True
assert record['decoded_video']['full_decode_passed'] is True and record['decoded_video']['frames']==576 and record['decoded_video']['duration_s']==24.
files={'video/'+p.name:p for p in v.iterdir() if p.is_file()}
files.update({'plots/'+p.name:p for p in (b/'plots_v1').iterdir() if p.is_file()})
for name in ['scripts/render_x650_cpp_fast.py','scripts/render_x650_isolated_validation.py','scripts/plot_x650_isolated_validation.py','tests/unit/test_x650_cpp_fast_render.py']:files['presentation_sources/'+name]=r/name
for name in ['render_process_v1.json','render_after_audit_v1.py','presentation_v1.sh','video_v1.log','video_v1.exit','plots_v1.log','plots_v1.exit','presentation_code_v1/manifest.json','archive_fast_media_v1.py']:files['context/'+name]=b/name
manifest=dict(kind='x650_cpp_fast_media_archive_v1',source_certificate=record['input_hashes']['report'],physical_input_sha256=record['input_hashes']['native_trace']['sha256'],full_decode=record['decoded_video'],scope='Recorded actual fast simulation presentation; no geometry cache; not new physics or hardware footage',files=[])
zpath=b/'fast_media_v1.zip'
with zipfile.ZipFile(zpath,'x',zipfile.ZIP_DEFLATED) as z:
 for name,p in sorted(files.items()):
  data=p.read_bytes();item=dict(entry=name,source_path=str(p),bytes=len(data),sha256=hashlib.sha256(data).hexdigest());manifest['files'].append(item);z.writestr(name,data)
  assert hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256']
 z.writestr('archive_manifest.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(zpath) as z:
 assert json.loads(z.read('archive_manifest.json'))==manifest
 for item in manifest['files']:
  data=z.read(item['entry']);assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256']
(b/'fast_media_v1_manifest.json').write_text(json.dumps(manifest,indent=2))
receipt=dict(path=str(zpath),bytes=zpath.stat().st_size,sha256=hashlib.sha256(zpath.read_bytes()).hexdigest(),entries=len(files),uncompressed_bytes=sum(f['bytes'] for f in manifest['files']),all_entries_verified=True,complete_decode=record['decoded_video'])
(b/'fast_media_v1_receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
