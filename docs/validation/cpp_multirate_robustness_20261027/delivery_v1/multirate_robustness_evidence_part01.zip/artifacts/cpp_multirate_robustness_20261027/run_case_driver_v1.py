from pathlib import Path
import sys,json,time,subprocess,hashlib
r=Path('/root/autodl-tmp/safe-aerial-manipulator-testbed');s=r/'artifacts/cpp_multirate_robustness_20261027'
case=sys.argv[1];assert case in ('mass085','mass115')
i=s/(case+'_inputs_v1');status=s/(case+'_job_status_v1.json');assert not status.exists()
state=dict(case=case,started_unix=time.time(),complete=False,physical_acceptance=False)
status.write_text(json.dumps(state,indent=2))
cmd=[sys.executable,str(r/'simulations/x650_cpp_multirate_robustness_v1/launch.py'),'--task',str(i/'task.json'),'--startup-manifest',str(i/'startup_manifest.json'),'--startup-sha256',hashlib.sha256((i/'startup_manifest.json').read_bytes()).hexdigest(),'--qualification-manifest',str(i/'qualification_manifest.json'),'--protocol',str(i/'protocol.json')]
result=subprocess.run(cmd,cwd=r)
state.update(exit_code=result.returncode,completed_unix=time.time(),complete=True,runtime_closed=not (r/'.amsim/runtime.json').exists())
status.write_text(json.dumps(state,indent=2))
sys.exit(result.returncode)
