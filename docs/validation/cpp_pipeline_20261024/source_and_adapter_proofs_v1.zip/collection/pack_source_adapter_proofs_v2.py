from pathlib import Path
import hashlib,json,zipfile
R=Path('/root/autodl-tmp/safe-aerial-manipulator-testbed');B=R/'artifacts/cpp_pipeline_20261024'
S=Path('/root/autodl-tmp/flyarm_state_cpp_build_20261024');W=Path('/root/autodl-tmp/flyarm_state_cpp_release_20261024')
P=R/'runs/x650_isolated_live_v1_20261024_131702_20177'
FIRST=R/'runs/x650_cpp_live_v1_20261024_153133_35311'
archive=B/'source_and_adapter_proofs_v1.zip';assert not archive.exists()
files={};external={};historical_references=[]
def identity(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1048576),b''):h.update(block)
 return {'path':str(p),'bytes':p.stat().st_size,'sha256':h.hexdigest()}
def add(p,arc):
 p=Path(p);assert p.is_file() and not p.is_symlink(),str(p)
 assert '..' not in Path(arc).parts and not str(arc).startswith('/')
 if p in files: assert files[p]==arc;return
 assert arc not in files.values(),arc
 files[p]=str(arc)
def tree(p,arc):
 for f in sorted(p.rglob('*')):
  if f.is_file() and '__pycache__' not in f.parts:add(f,str(Path(arc)/f.relative_to(p)))
for root,label in ((S,'source_unoptimized'),(W,'source_release')):
 tree(root/'src',label+'/src')
 for name in ('source_build_proof.json','unit_final_v5.log','unit.log','build_binding_v3.log','build_binding_v4.log','build_final_v5.log','build_v1.log','build_v2.log','build.log','parity.log','ros_probe_final_v5.log','ros_probe_final_v6.log','ros_probe.log','qualification.exit','qualification.log','run_qualification.sh','source_copy_receipt.json','audit_x650_cpp_source.py','run_source_hold1_audit.sh','source_hold1_audit.exit','source_hold1_audit.log','source_hold_v1_audit.json'):
  f=root/name
  if f.is_file():add(f,label+'/'+name)
 for name in ('recorded_parity_v1','ros_binding_probe_v1','ros_binding_probe_v2','ros_binding_probe_v3','source_audit_software_v1','audit_v2'):
  p=root/name
  if p.is_dir():tree(p,label+'/'+name)
 for target in ('state_source','test_source_core','replay_source_core'):
  add(root/f'build/flyarm_state_cpp/CMakeFiles/{target}.dir/flags.make',f'{label}/compile_flags/{target}.flags.make')
 for relative in ('install/flyarm_state_cpp/lib/flyarm_state_cpp/state_source','build/flyarm_state_cpp/test_source_core','build/flyarm_state_cpp/replay_source_core'):
  add(root/relative,label+'/'+relative)
for name in ('adapter_contract_v1','transport_v1'):tree(B/name,'repository_artifacts/'+name)
for name in ('source_cpp_package_v2.zip','source_cpp_binding_v5.zip'):
 add(Path('/root/autodl-tmp')/name,'original_source_bundles/'+name)
parity=json.loads((S/'recorded_parity_v1/report.json').read_text())
for item in parity['source_identities']:
 p=Path(item['path']);assert p.is_relative_to(P);add(p,'prior_hold25_parity_inputs/'+str(p.relative_to(P)))
for relative in ('simulations/x650_wholebody_mpc_v1/estimated_feedback.py','simulations/x650_wholebody_mpc_v1/hover_reference.py','control_packages/x650_wholebody_v1/x650_wholebody/ts20_runtime.py','control_packages/x650_wholebody_v1/x650_wholebody/api.py','control_packages/x650_wholebody_v1/x650_wholebody/model.py'):
 add(R/relative,'offline_oracle_sources/'+relative)
# Validate embedded artifact claims and retain explicitly excluded current-hold
# identities; that complete raw run is already in the parent's first-hold ZIP.
def claims(value,source_report):
 if isinstance(value,dict):
  if {'path','bytes','sha256'} <= value.keys():
   p=Path(value['path']);actual=identity(p)
   if not all(actual[k]==value[k] for k in ('bytes','sha256')):
    assert source_report.is_relative_to(S/'ros_binding_probe_v1'),(str(source_report),str(p))
    historical_references.append({'report':str(source_report),'expected':{k:value[k] for k in ('path','bytes','sha256')},'current':actual,'reason':'Preserved earlier lifecycle probe, not final qualification; its original path was reused before final source freeze. Report bytes retained, unavailable historical binary/script not fabricated.'})
   if p.is_relative_to(FIRST):external[str(p)]={**actual,'reason':'Current first-hold raw data is in the separate full-run archive; intentionally not duplicated'}
  for v in value.values():claims(v,source_report)
 elif isinstance(value,list):
  for v in value:claims(v,source_report)
for p in list(files):
 if p.suffix=='.json':
  try:v=json.loads(p.read_text())
  except (UnicodeError,json.JSONDecodeError):continue
  # Negative-test fixtures intentionally contain altered copied path metadata;
  # do not mislabel them as certificates.
  if 'mutated_worker_fixture' not in p.parts and 'truncated_worker_fixture' not in p.parts:
   claims(v,p)
entries=[]
for p,arc in sorted(files.items(),key=lambda x:x[1]):
 assert not p.is_relative_to(FIRST),p
 entries.append({'archive_path':arc,**identity(p),'content_role':'original bytes; test fixtures retain explicit artificial/negative scope'})
manifest={'schema_version':1,'kind':'source_adapter_supplemental_archive_v1','scope':'Unoptimized and Release C++ source software proofs, old source parity raw inputs, adapter/transport software probes, and independent first-hold source audit; no complete physical-hold success claim',
 'excluded_current_first_hold_raw':str(FIRST),'files':entries,'external_current_hold_artifacts':sorted(external.values(),key=lambda x:x['path']),
 'historical_reference_mismatches':historical_references,'collection_script':identity(Path(__file__))}
manifest_raw=json.dumps(manifest,indent=2,allow_nan=False).encode()
(B/'source_and_adapter_proofs_v1.manifest.json').write_bytes(manifest_raw)
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for entry in entries:z.write(entry['path'],entry['archive_path'])
 z.writestr('manifest.json',manifest_raw)
 z.write(__file__,'collection/'+Path(__file__).name)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(entries)+2
 for entry in entries:
  h=hashlib.sha256();size=0
  with z.open(entry['archive_path']) as f:
   for block in iter(lambda:f.read(1048576),b''):h.update(block);size+=len(block)
  assert size==entry['bytes'] and h.hexdigest()==entry['sha256'],entry['archive_path']
 assert z.read('manifest.json')==manifest_raw
receipt={'archive':identity(archive),'manifest':identity(B/'source_and_adapter_proofs_v1.manifest.json'),'files':len(entries),'uncompressed_source_bytes':sum(e['bytes'] for e in entries),'compressed_below_50_mb':archive.stat().st_size<50_000_000,'all_entries_sha256_verified':True,'external_current_hold_artifacts':len(external),'historical_reference_mismatches':len(historical_references)}
(B/'source_and_adapter_proofs_v1.receipt.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps(receipt,indent=2))
assert receipt['compressed_below_50_mb'],'Archive exceeds 50MB: report only, do not transfer'
