from pathlib import Path
from types import SimpleNamespace as N
import json,sys,importlib.util,time,hashlib
r=Path("/root/autodl-tmp/safe-aerial-manipulator-testbed");sys.path.insert(0,str(r));b=r/"artifacts/cpp_pipeline_20261024/adapter_contract_v1"
spec=importlib.util.spec_from_file_location("scratch_cpp_adapter",b/"run_case.py");m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
from flyarm_control_interfaces import msg
from rclpy.serialization import serialize_message,deserialize_message
serialize_message(msg.SourceBinding());serialize_message(msg.SourceBindingAck())
old=r/"runs/x650_isolated_live_v1_20261024_131702_20177/estimated_feedback.json";doc=json.loads(old.read_text());sent=[]
e=m.CppLiveExtension({},{});e.session=321;e.epoch=1;e.task_sha="aa"*32;e.msg=msg;e.binding_ack=None
raw=json.loads((r/"artifacts/cpp_pipeline_20261024/historical_raw_v1/case_0000.json").read_text());e.cpp_manifest={"config":raw["config"]}
def publish(s):
 wire=serialize_message(s);v=deserialize_message(wire,msg.SourceBinding);sent.append(v)
 a=msg.SourceBindingAck();a.session_id=s.session_id;a.epoch=s.epoch;a.configuration_sha256=s.configuration_sha256;a.binding_sequence=s.binding_sequence;a.binding_issued_monotonic_ns=s.issued_monotonic_ns;a.observed_monotonic_ns=time.monotonic_ns();a.accepted=True;a.rejection_code=0;e._on_binding_ack(a)
e.binding_pub=N(publish=publish)
def wait(predicate,*args):
 assert predicate(),args
loop=N(fixed_reference=N(document=doc["reference"]),feedback_adapter=N(document=doc))
try:
 e._bind_actual_source(N(vehicle=N(wait=wait)),loop)
except Exception:
 a=e.binding_ack;s=sent[0];print({"ack_elapsed_ms":(a.observed_monotonic_ns-s.issued_monotonic_ns)/1e6,"hash_equal":list(a.configuration_sha256)==list(s.configuration_sha256),"issued_equal":a.binding_issued_monotonic_ns==s.issued_monotonic_ns,"accepted":a.accepted,"rejection":a.rejection_code});raise
assert len(sent)==1 and sent[0].ref_timestamp==doc["reference"]["px4_reference_at_bind"]["ref_timestamp"]
for name in ("vxy_reset_counter","vz_reset_counter","quat_reset_counter"):
 assert getattr(sent[0],name)==doc["extra_reset_counters_at_bind"][name]
report={"kind":"cpp_adapter_original_reference_wire_construction_v1","passed":True,"no_ros_node_created":True,"no_actuator_published":True,"input_reference":{"path":str(old),"sha256":hashlib.sha256(old.read_bytes()).hexdigest()},"adapter_sha256":hashlib.sha256((b/"run_case.py").read_bytes()).hexdigest(),"ref_timestamp_original_type":type(doc["reference"]["px4_reference_at_bind"]["ref_timestamp"]).__name__,"ref_timestamp_wire":sent[0].ref_timestamp,"original_reference_and_extra_resets_equal":True,"scope":"real generated ROS messages and CDR roundtrip only; no simulation or handoff acceptance"}
(b/"report_after_ground_type_support.json").write_text(json.dumps(report,indent=2));print(json.dumps(report))
