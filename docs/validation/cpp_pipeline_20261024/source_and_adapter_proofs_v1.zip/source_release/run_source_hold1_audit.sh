#!/bin/bash
set -e -o pipefail
W=/root/autodl-tmp/flyarm_state_cpp_release_20261024
trap 'code=$?; printf "%s\n" "$code" > "$W/source_hold1_audit.exit"' EXIT
source /opt/ros/humble/setup.bash
source /root/autodl-tmp/ros2_px4_ws/install/setup.bash
source /root/autodl-tmp/flyarm_ros2_live_v1_20261023/install/setup.bash
source /root/autodl-tmp/flyarm_state_cpp_build_20261024/install/local_setup.bash
source "$W/install/local_setup.bash"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
/usr/bin/python3 - <<'PY'
import pathlib,sys,importlib.util
R=pathlib.Path('/root/autodl-tmp/safe-aerial-manipulator-testbed');W=pathlib.Path('/root/autodl-tmp/flyarm_state_cpp_release_20261024')
sys.path[:0]=[str(R),str(R/'control_packages/x650_wholebody_v1')]
spec=importlib.util.spec_from_file_location('source_audit',W/'audit_x650_cpp_source.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a);a.ROOT=R
sys.argv=[str(W/'audit_x650_cpp_source.py'),'--run',str(R/'runs/x650_cpp_live_v1_20261024_153133_35311'),'--output',str(W/'source_hold_v1_audit.json')]
raise SystemExit(a.main())
PY
