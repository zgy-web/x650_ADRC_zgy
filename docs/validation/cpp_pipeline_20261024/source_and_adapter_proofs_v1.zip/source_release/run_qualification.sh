#!/bin/bash
set -e -o pipefail
W=/root/autodl-tmp/flyarm_state_cpp_release_20261024
R=/root/autodl-tmp/safe-aerial-manipulator-testbed
trap 'code=$?; printf "%s\n" "$code" > "$W/qualification.exit"' EXIT
source /opt/ros/humble/setup.bash
source /root/autodl-tmp/ros2_px4_ws/install/setup.bash
source /root/autodl-tmp/flyarm_ros2_live_v1_20261023/install/setup.bash
source /root/autodl-tmp/flyarm_state_cpp_build_20261024/install/local_setup.bash
cd "$W"
export CMAKE_BUILD_PARALLEL_LEVEL=2 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
colcon build --packages-select flyarm_state_cpp --executor sequential --cmake-args -DCMAKE_BUILD_TYPE=Release -DCMAKE_CXX_FLAGS_RELEASE='-O3 -DNDEBUG' -DBUILD_TESTING=ON > build.log 2>&1
ctest --test-dir "$W/build/flyarm_state_cpp" --output-on-failure > unit.log 2>&1
"$W/build/flyarm_state_cpp/test_source_core" >> unit.log 2>&1
source "$W/install/local_setup.bash"
cd "$R"
/usr/bin/python3 "$W/src/flyarm_state_cpp/test/compare_recorded_source.py" --run "$R/runs/x650_isolated_live_v1_20261024_131702_20177" --executable "$W/build/flyarm_state_cpp/replay_source_core" --output "$W/recorded_parity_v1" > "$W/parity.log" 2>&1
ROS_DOMAIN_ID=197 /usr/bin/python3 "$W/src/flyarm_state_cpp/test/probe_source_ros.py" --executable "$W/install/flyarm_state_cpp/lib/flyarm_state_cpp/state_source" --output "$W/ros_binding_probe_v1" > "$W/ros_probe.log" 2>&1
