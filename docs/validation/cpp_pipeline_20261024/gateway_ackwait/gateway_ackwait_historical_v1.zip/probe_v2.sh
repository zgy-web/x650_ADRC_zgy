#!/bin/bash
set -o pipefail
source /opt/ros/humble/setup.bash
source /root/autodl-tmp/ros2_px4_ws/install/setup.bash
source /root/autodl-tmp/flyarm_ros2_live_v1_20261023/install/setup.bash
source /root/autodl-tmp/flyarm_gateway_ackwait_20261024/install/setup.bash
export PYTHONPATH=/root/autodl-tmp/amsim-venv/lib/python3.10/site-packages:$PYTHONPATH
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1
/usr/bin/python3 /root/autodl-tmp/flyarm_gateway_ackwait_20261024/src/scripts/probe_x650_consumption_wait.py --output /root/autodl-tmp/flyarm_gateway_ackwait_20261024/consumption_probe_v2 > /root/autodl-tmp/flyarm_gateway_ackwait_20261024/consumption_probe_v2.log 2>&1
printf '%s\n' "$?" > /root/autodl-tmp/flyarm_gateway_ackwait_20261024/consumption_probe_v2.exit
