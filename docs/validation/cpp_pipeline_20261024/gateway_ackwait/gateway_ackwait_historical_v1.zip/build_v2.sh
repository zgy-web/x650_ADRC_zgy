#!/bin/bash
set -o pipefail
source /opt/ros/humble/setup.bash
source /root/autodl-tmp/ros2_px4_ws/install/setup.bash
source /root/autodl-tmp/flyarm_ros2_live_v1_20261023/install/setup.bash
cd /root/autodl-tmp/flyarm_gateway_ackwait_20261024
colcon --log-base log build --base-paths src/ros2_ws/src/flyarm_control_gateway --build-base build --install-base install --cmake-args -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=ON -DMAVLINK_INCLUDE_DIR=/root/autodl-tmp/PX4-Autopilot/build/px4_sitl_default/mavlink > build_v2.log 2>&1
rc=$?
if [ "$rc" = 0 ]; then ctest --test-dir build/flyarm_control_gateway --output-on-failure >> build_v2.log 2>&1;rc=$?;fi
printf '%s\n' "$rc" > build_v2.exit
