source /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_pipeline_20261024/stream_environment_v1.sh
set +e
/usr/bin/python3 simulations/x650_cpp_live_v1/launch.py --task /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_pipeline_20261024/hold_inputs_stream_v1/task.json --startup-manifest /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_pipeline_20261024/hold_inputs_stream_v1/startup_manifest.json --startup-sha256 56a4f8850e62dbfacc322bf17fb88fa6ff2ed8ea277a7f8f0805e913c77cfe62 --qualification-manifest /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_pipeline_20261024/hold_inputs_stream_v1/qualification_manifest.json > /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_pipeline_20261024/hold_stream_v1.log 2>&1
code=$?
printf "%s\n" "$code" > /root/autodl-tmp/safe-aerial-manipulator-testbed/artifacts/cpp_pipeline_20261024/hold_stream_v1.exit
exit "$code"
