set -e
source /opt/ros/humble/setup.bash
source /root/autodl-tmp/ros2_px4_ws/install/setup.bash
source /root/autodl-tmp/flyarm_ros2_live_v1_20261023/install/setup.bash
source /root/autodl-tmp/flyarm_cpp_pipeline_build_20261024/install/setup.bash
source /root/autodl-tmp/flyarm_state_cpp_build_20261024/install/local_setup.bash
source /root/autodl-tmp/flyarm_state_cpp_release_20261024/install/local_setup.bash
source /root/autodl-tmp/flyarm_gateway_streaming_20261024/install/local_setup.bash
export PYTHONPATH=/usr/lib/python3/dist-packages:/root/autodl-tmp/amsim-venv/lib/python3.10/site-packages:${PYTHONPATH:-}
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
cd /root/autodl-tmp/safe-aerial-manipulator-testbed
