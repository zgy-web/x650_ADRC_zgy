from pathlib import Path
import zipfile,hashlib,json
r=Path('/root/autodl-tmp/safe-aerial-manipulator-testbed');b=r/'artifacts/cpp_pipeline_20261024'
assert not (r/'.amsim/runtime.json').exists()
assert json.loads((b/'hold_stream_v2_audit_v2/report.json').read_text())['passed'] is True
folders={
 'accepted/launch':r/'runs/x650_cpp_launch_20261024_163355_43016',
 'accepted/run':r/'runs/x650_cpp_live_v1_20261024_163442_43018',
 'ground_start_failure/launch':r/'runs/x650_cpp_launch_20261024_162809_41788',
 'ground_start_failure/run':r/'runs/x650_cpp_live_v1_20261024_162852_41790',
 'audit_initial':b/'hold_stream_v2_audit',
 'audit_accepted':b/'hold_stream_v2_audit_v2',
 'inputs':b/'hold_inputs_stream_v1',
 'gateway_source_sync':b/'gateway_streaming_source_sync_v1'}
files={prefix+'/'+p.relative_to(folder).as_posix():p for prefix,folder in folders.items() for p in folder.rglob('*') if p.is_file()}
for name in ['stream_environment_v1.sh','stream_environment_v2.sh','hold_stream_v1.sh','hold_stream_v2.sh','hold_stream_v1.log','hold_stream_v2.log','hold_stream_v1.exit','hold_stream_v2.exit','hold_stream_dryrun_v1.log','hold_stream_dryrun_v2.log','archive_stream_hold_v2.py']:
 files['launch_context/'+name]=b/name
for rel in ['scripts/audit_x650_cpp_hold.py','tests/unit/test_x650_cpp_hold_audit.py','scripts/audit_x650_streaming_consumption.py','tests/unit/test_x650_streaming_consumption_audit.py','simulations/x650_cpp_live_v1/launch.py','simulations/x650_cpp_live_v1/qualification.py','tests/unit/test_x650_cpp_qualification.py']:
 files['final_audit_sources/'+rel]=r/rel
manifest={'kind':'cpp_stream_hold_original_archive_v1','simulation_only':True,'accepted_run':'x650_cpp_live_v1_20261024_163442_43018','scope':'Complete accepted 30 s physical hold and immutable original records; also retain prior ground startup failure and initial audit failure with their verifier mapping. No figure-eight or hardware claim.','files':[]}
out=b/'hold_stream_v2_full.zip'
assert not out.exists()
with zipfile.ZipFile(out,'x',zipfile.ZIP_DEFLATED) as z:
 for name,p in sorted(files.items()):
  data=p.read_bytes();digest=hashlib.sha256(data).hexdigest();z.writestr(name,data)
  assert hashlib.sha256(p.read_bytes()).hexdigest()==digest
  manifest['files'].append({'entry':name,'source_path':str(p),'bytes':len(data),'sha256':digest})
 z.writestr('archive_manifest.json',json.dumps(manifest,indent=2))
(b/'hold_stream_v2_full_manifest.json').write_text(json.dumps(manifest,indent=2))
receipt={'path':str(out),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'entries':len(files),'uncompressed_bytes':sum(v['bytes'] for v in manifest['files'])}
(b/'hold_stream_v2_full_receipt.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps(receipt))
